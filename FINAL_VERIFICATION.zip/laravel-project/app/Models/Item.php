<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Item extends Model
{
    protected $fillable = [
        'item_code',
        'item_name',
        'item_name_urdu',
        'category',
        'unit',
        'purchase_rate',
        'sale_rate',
        'opening_stock',
        'current_stock',
        'min_stock',
        'description',
        'status',
    ];

    protected $casts = [
        'purchase_rate' => 'decimal:2',
        'sale_rate' => 'decimal:2',
        'opening_stock' => 'decimal:2',
        'current_stock' => 'decimal:2',
        'min_stock' => 'decimal:2',
    ];

    public function purchaseItems(): HasMany
    {
        return $this->hasMany(PurchaseItem::class);
    }

    public function saleItems(): HasMany
    {
        return $this->hasMany(SaleItem::class);
    }

    public function stockMovements(): HasMany
    {
        return $this->hasMany(StockMovement::class);
    }

    public function getDisplayNameAttribute(): string
    {
        $lang = app()->getLocale();
        if ($lang === 'ur' && !empty($this->item_name_urdu)) {
            return $this->item_name_urdu;
        }
        return $this->item_name;
    }

    public function getDisplayNameFullAttribute(): string
    {
        $name = $this->item_name;
        if (!empty($this->item_name_urdu)) {
            $name .= ' / ' . $this->item_name_urdu;
        }
        return $name;
    }

    public function isLowStock(): bool
    {
        return $this->current_stock <= $this->min_stock;
    }
}


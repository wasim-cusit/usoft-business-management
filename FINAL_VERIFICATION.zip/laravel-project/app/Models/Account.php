<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Account extends Model
{
    protected $fillable = [
        'account_code',
        'account_name',
        'account_name_urdu',
        'account_type',
        'user_type_id',
        'contact_person',
        'phone',
        'mobile',
        'email',
        'address',
        'city',
        'opening_balance',
        'balance_type',
        'status',
    ];

    protected $casts = [
        'opening_balance' => 'decimal:2',
    ];

    public function userType(): BelongsTo
    {
        return $this->belongsTo(UserType::class);
    }

    public function purchases(): HasMany
    {
        return $this->hasMany(Purchase::class);
    }

    public function sales(): HasMany
    {
        return $this->hasMany(Sale::class);
    }

    public function transactions(): HasMany
    {
        return $this->hasMany(Transaction::class);
    }

    public function getDisplayNameAttribute(): string
    {
        $lang = app()->getLocale();
        if ($lang === 'ur' && !empty($this->account_name_urdu)) {
            return $this->account_name_urdu;
        }
        return $this->account_name;
    }

    public function getDisplayNameFullAttribute(): string
    {
        $name = $this->account_name;
        if (!empty($this->account_name_urdu)) {
            $name .= ' / ' . $this->account_name_urdu;
        }
        return $name;
    }
}


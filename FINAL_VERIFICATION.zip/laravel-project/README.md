# Laravel 11 Business Management System
## Yusuf & Co (یوسف اینڈ کو)

Complete migration from custom PHP to Laravel 11.

## Installation

1. Install Laravel 11:
```bash
composer create-project laravel/laravel usoft-laravel "^11.0"
cd usoft-laravel
```

2. Copy all files from this directory to your Laravel project

3. Install dependencies:
```bash
composer install
```

4. Configure `.env`:
```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=usoft_business
DB_USERNAME=root
DB_PASSWORD=

APP_LOCALE=en
FALLBACK_LOCALE=en
```

5. Run migrations:
```bash
php artisan migrate
```

6. Seed default data:
```bash
php artisan db:seed
```

7. Link storage:
```bash
php artisan storage:link
```

8. Start server:
```bash
php artisan serve
```

## Project Structure

All Laravel files are organized in the standard Laravel structure:
- `app/` - Application logic
- `database/migrations/` - Database migrations
- `resources/views/` - Blade templates
- `resources/lang/` - Language files
- `routes/` - Route definitions
- `public/assets/` - Public assets

## Features

- ✅ Complete authentication system
- ✅ Accounts management (CRUD)
- ✅ Items management (CRUD)
- ✅ Purchases & Sales with stock management
- ✅ Transactions (Debit, Credit, Journal)
- ✅ Comprehensive reports
- ✅ Bilingual support (English/Urdu)
- ✅ Responsive design
- ✅ SMS integration


<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AccountApiController;
use App\Http\Controllers\Api\ItemApiController;
use App\Http\Controllers\Api\PurchaseApiController;
use App\Http\Controllers\Api\SaleApiController;
use App\Http\Controllers\Api\TransactionApiController;
use App\Http\Controllers\Api\UserTypeApiController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/

Route::middleware(['auth:sanctum'])->group(function () {
    
    // Accounts API
    Route::prefix('accounts')->name('api.accounts.')->group(function () {
        Route::post('/', [AccountApiController::class, 'store'])->name('store');
        Route::put('/{account}', [AccountApiController::class, 'update'])->name('update');
        Route::delete('/{account}', [AccountApiController::class, 'destroy'])->name('destroy');
    });
    
    // Items API
    Route::prefix('items')->name('api.items.')->group(function () {
        Route::post('/', [ItemApiController::class, 'store'])->name('store');
        Route::put('/{item}', [ItemApiController::class, 'update'])->name('update');
        Route::delete('/{item}', [ItemApiController::class, 'destroy'])->name('destroy');
    });
    
    // Purchases API
    Route::prefix('purchases')->name('api.purchases.')->group(function () {
        Route::post('/', [PurchaseApiController::class, 'store'])->name('store');
    });
    
    // Sales API
    Route::prefix('sales')->name('api.sales.')->group(function () {
        Route::post('/', [SaleApiController::class, 'store'])->name('store');
    });
    
    // Transactions API
    Route::prefix('transactions')->name('api.transactions.')->group(function () {
        Route::post('/debit', [TransactionApiController::class, 'storeDebit'])->name('debit.store');
        Route::post('/credit', [TransactionApiController::class, 'storeCredit'])->name('credit.store');
        Route::post('/journal', [TransactionApiController::class, 'storeJournal'])->name('journal.store');
    });
    
    // User Types API
    Route::prefix('user-types')->name('api.user-types.')->group(function () {
        Route::post('/', [UserTypeApiController::class, 'store'])->name('store');
        Route::put('/{userType}', [UserTypeApiController::class, 'update'])->name('update');
        Route::delete('/{userType}', [UserTypeApiController::class, 'destroy'])->name('destroy');
    });
});


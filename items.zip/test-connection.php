<?php
/**
 * Database Connection Test
 * یہ فائل ڈیٹا بیس کنکشن چیک کرنے کے لیے ہے
 */

echo "<!DOCTYPE html>";
echo "<html lang='ur' dir='rtl'>";
echo "<head><meta charset='utf-8'><title>کنکشن ٹیسٹ</title></head>";
echo "<body style='font-family: Arial; padding: 20px; direction: rtl;'>";
echo "<h1>ڈیٹا بیس کنکشن ٹیسٹ</h1>";

// Test database connection
try {
    require_once 'config/database.php';
    $db = getDB();
    echo "<p style='color: green;'>✅ ڈیٹا بیس کنکشن کامیاب!</p>";
    
    // Check if tables exist
    $tables = ['users', 'accounts', 'items', 'purchases', 'sales', 'transactions'];
    echo "<h2>ٹیبلز چیک:</h2><ul>";
    foreach ($tables as $table) {
        try {
            $stmt = $db->query("SHOW TABLES LIKE '$table'");
            if ($stmt->rowCount() > 0) {
                echo "<li style='color: green;'>✅ $table موجود ہے</li>";
            } else {
                echo "<li style='color: red;'>❌ $table موجود نہیں</li>";
            }
        } catch (Exception $e) {
            echo "<li style='color: red;'>❌ $table: " . $e->getMessage() . "</li>";
        }
    }
    echo "</ul>";
    
    // Check default user
    try {
        $stmt = $db->query("SELECT COUNT(*) as count FROM users WHERE username = 'adil'");
        $result = $stmt->fetch();
        if ($result['count'] > 0) {
            echo "<p style='color: green;'>✅ ڈیفالٹ صارف موجود ہے</p>";
        } else {
            echo "<p style='color: orange;'>⚠️ ڈیفالٹ صارف موجود نہیں - براہ کرم schema.sql ایمپورٹ کریں</p>";
        }
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ صارف چیک ناکام: " . $e->getMessage() . "</p>";
    }
    
    echo "<hr>";
    echo "<p><a href='login.php'>لاگ ان صفحہ پر جائیں</a></p>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ ڈیٹا بیس کنکشن ناکام: " . $e->getMessage() . "</p>";
    echo "<h2>مسائل کا حل:</h2>";
    echo "<ol>";
    echo "<li>XAMPP Control Panel سے MySQL شروع کریں</li>";
    echo "<li>phpMyAdmin میں ڈیٹا بیس بنائیں: <code>usoft_business</code></li>";
    echo "<li><code>database/schema.sql</code> فائل ایمپورٹ کریں</li>";
    echo "<li><code>config/database.php</code> میں تفصیلات چیک کریں</li>";
    echo "</ol>";
}

echo "</body></html>";
?>


# Laravel 11 MVC Folder Structure
## Business Management System - Yusuf & Co

## Complete Directory Structure

```
usoft-laravel/
├── app/                                    # Application Core
│   ├── Console/
│   │   └── Kernel.php
│   ├── Exceptions/
│   │   └── Handler.php
│   ├── Http/
│   │   ├── Controllers/                    # Controllers (MVC - C)
│   │   │   ├── Auth/
│   │   │   │   └── LoginController.php     ✅ Created
│   │   │   ├── Api/                        # API Controllers
│   │   │   │   ├── AccountApiController.php
│   │   │   │   ├── ItemApiController.php
│   │   │   │   ├── PurchaseApiController.php
│   │   │   │   ├── SaleApiController.php
│   │   │   │   ├── TransactionApiController.php
│   │   │   │   └── UserTypeApiController.php
│   │   │   ├── AccountController.php       # Accounts CRUD
│   │   │   ├── DashboardController.php     ✅ Created
│   │   │   ├── ItemController.php          # Items CRUD
│   │   │   ├── PurchaseController.php      # Purchases Management
│   │   │   ├── ReportController.php        # All Reports
│   │   │   ├── SaleController.php          # Sales Management
│   │   │   ├── TransactionController.php   # Transactions
│   │   │   └── UserTypeController.php      # User Types CRUD
│   │   ├── Middleware/                     # Custom Middleware
│   │   │   ├── SetLocale.php               # Language switching
│   │   │   └── RequireLogin.php            # (Using Laravel's auth middleware)
│   │   └── Requests/                       # Form Request Validation
│   │       ├── AccountRequest.php
│   │       ├── ItemRequest.php
│   │       ├── PurchaseRequest.php
│   │       ├── SaleRequest.php
│   │       └── TransactionRequest.php
│   ├── Models/                              # Models (MVC - M)
│   │   ├── User.php                        ✅ Created
│   │   ├── UserType.php                    ✅ Created
│   │   ├── Account.php                     ✅ Created
│   │   ├── Item.php                        ✅ Created
│   │   ├── Purchase.php                    ✅ Created
│   │   ├── PurchaseItem.php                ✅ Created
│   │   ├── Sale.php                        ✅ Created
│   │   ├── SaleItem.php                    ✅ Created
│   │   ├── Transaction.php                 ✅ Created
│   │   └── StockMovement.php               ✅ Created
│   ├── Services/                           # Business Logic Services
│   │   ├── StockService.php                # Stock management logic
│   │   ├── PurchaseService.php             # Purchase business logic
│   │   ├── SaleService.php                 # Sale business logic
│   │   └── ReportService.php               # Report calculations
│   ├── Helpers/                             # Helper Functions
│   │   └── helpers.php                     ✅ Created
│   └── Providers/
│       └── AppServiceProvider.php
│
├── bootstrap/
│   ├── app.php
│   └── cache/
│
├── config/                                  # Configuration Files
│   ├── app.php                             # App config (locale, timezone)
│   ├── auth.php                            # Authentication config
│   ├── database.php                        # Database config
│   ├── session.php                         # Session config
│   └── ...
│
├── database/
│   ├── migrations/                          # Database Migrations
│   │   ├── 2024_01_01_000001_create_user_types_table.php      ✅ Created
│   │   ├── 2024_01_01_000002_create_users_table.php          ✅ Created
│   │   ├── 2024_01_01_000003_create_accounts_table.php        ✅ Created
│   │   ├── 2024_01_01_000004_create_items_table.php           ✅ Created
│   │   ├── 2024_01_01_000005_create_purchases_table.php        ✅ Created
│   │   ├── 2024_01_01_000006_create_purchase_items_table.php  ✅ Created
│   │   ├── 2024_01_01_000007_create_sales_table.php           ✅ Created
│   │   ├── 2024_01_01_000008_create_sale_items_table.php     ✅ Created
│   │   ├── 2024_01_01_000009_create_transactions_table.php    ✅ Created
│   │   └── 2024_01_01_000010_create_stock_movements_table.php ✅ Created
│   ├── seeders/                             # Database Seeders
│   │   ├── DatabaseSeeder.php
│   │   ├── UserSeeder.php                   # Default admin user
│   │   └── UserTypeSeeder.php               # Default user types
│   └── factories/                           # Model Factories (if needed)
│
├── public/                                   # Public Assets (Web Root)
│   ├── index.php                            # Entry point
│   ├── assets/                              # Application Assets
│   │   ├── css/
│   │   │   └── style.css                   # From old assets/css/style.css
│   │   ├── js/
│   │   │   └── main.js                     # From old assets/js/main.js
│   │   └── images/                          # Images
│   └── .htaccess
│
├── resources/                                # Resources (Views, Lang, etc.)
│   ├── views/                               # Blade Templates (MVC - V)
│   │   ├── layouts/                         # Layout Templates
│   │   │   ├── app.blade.php               # Main layout (from header.php + footer.php)
│   │   │   └── guest.blade.php             # Guest layout (for login)
│   │   ├── components/                      # Blade Components
│   │   │   ├── stat-card.blade.php         # Stat card component
│   │   │   ├── sidebar.blade.php           # Sidebar component
│   │   │   └── notification.blade.php       # Notification component
│   │   ├── auth/                            # Authentication Views
│   │   │   └── login.blade.php             # Login page (from login.php)
│   │   ├── dashboard/                       # Dashboard Views
│   │   │   └── index.blade.php             # Dashboard (from index.php)
│   │   ├── accounts/                        # Account Views
│   │   │   ├── index.blade.php              # List (from accounts/list.php)
│   │   │   ├── create.blade.php             # Create (from accounts/create.php)
│   │   │   ├── edit.blade.php               # Edit (from accounts/edit.php)
│   │   │   └── show.blade.php               # View (from accounts/view.php)
│   │   ├── user-types/                      # User Type Views
│   │   │   ├── index.blade.php              # List (from accounts/user-types.php)
│   │   │   └── modal.blade.php             # User type modal
│   │   ├── items/                           # Item Views
│   │   │   ├── index.blade.php              # List (from items/list.php)
│   │   │   ├── create.blade.php             # Create (from items/create.php)
│   │   │   └── edit.blade.php               # Edit (from items/edit.php)
│   │   ├── purchases/                       # Purchase Views
│   │   │   ├── index.blade.php              # List (from purchases/list.php)
│   │   │   ├── create.blade.php             # Create (from purchases/create.php)
│   │   │   └── show.blade.php               # View (from purchases/view.php)
│   │   ├── sales/                           # Sale Views
│   │   │   ├── index.blade.php              # List (from sales/list.php)
│   │   │   ├── create.blade.php             # Create (from sales/create.php)
│   │   │   └── show.blade.php               # View (from sales/view.php)
│   │   ├── transactions/                    # Transaction Views
│   │   │   ├── index.blade.php              # List (from transactions/list.php)
│   │   │   ├── debit.blade.php              # Debit (from transactions/debit.php)
│   │   │   ├── credit.blade.php             # Credit (from transactions/credit.php)
│   │   │   └── journal.blade.php            # Journal (from transactions/journal.php)
│   │   └── reports/                         # Report Views
│   │       ├── party-ledger.blade.php       # Party ledger
│   │       ├── stock-detail.blade.php       # Stock detail
│   │       ├── stock-ledger.blade.php       # Stock ledger
│   │       ├── balance-sheet.blade.php      # Balance sheet
│   │       ├── cash-book.blade.php          # Cash book
│   │       ├── daily-book.blade.php         # Daily book
│   │       ├── loan-slip.blade.php          # Loan slip
│   │       ├── rate-list.blade.php          # Rate list
│   │       ├── stock-check.blade.php        # Stock check
│   │       └── all-bills.blade.php          # All bills
│   ├── lang/                                # Language Files
│   │   ├── en/                              # English Translations
│   │   │   └── messages.php                 # All English strings
│   │   └── ur/                              # Urdu Translations
│   │       └── messages.php                 # All Urdu strings
│   └── js/                                  # JavaScript (if using Vite)
│       └── app.js
│
├── routes/                                   # Route Definitions
│   ├── web.php                              ✅ Created (Web routes)
│   ├── api.php                              ✅ Created (API routes)
│   └── console.php                          # Artisan commands
│
├── storage/                                  # Storage (Logs, Cache, etc.)
│   ├── app/
│   ├── framework/
│   └── logs/
│
├── tests/                                    # Tests
│   ├── Feature/
│   └── Unit/
│
├── vendor/                                   # Composer Dependencies
│
├── .env                                      # Environment Configuration
├── .env.example                              # Environment Template
├── .gitignore
├── artisan                                   # Artisan CLI
├── composer.json                             ✅ Created
├── composer.lock
├── package.json                              # NPM Dependencies (if using Vite)
├── phpunit.xml                               # PHPUnit Config
└── README.md                                 ✅ Created

```

## MVC Pattern Explanation

### Model (M) - `app/Models/`
- **Purpose:** Data layer - Database interactions
- **Files:** All Eloquent models (User, Account, Item, etc.)
- **Responsibilities:**
  - Database queries
  - Relationships
  - Data validation rules
  - Business logic related to data

### View (V) - `resources/views/`
- **Purpose:** Presentation layer - User interface
- **Files:** All Blade templates (.blade.php files)
- **Responsibilities:**
  - Display data
  - User interaction forms
  - HTML/CSS/JavaScript
  - Bilingual support

### Controller (C) - `app/Http/Controllers/`
- **Purpose:** Logic layer - Request handling
- **Files:** All controller classes
- **Responsibilities:**
  - Handle HTTP requests
  - Process form submissions
  - Call models for data
  - Return views with data
  - Business logic coordination

## File Mapping (Old → New)

### Old Structure → Laravel Structure

```
OLD                                    NEW
─────────────────────────────────────────────────────────────
config/config.php              →      config/app.php
config/database.php            →      config/database.php
config/language.php            →      resources/lang/en/messages.php
                                      resources/lang/ur/messages.php

includes/header.php            →      resources/views/layouts/app.blade.php
includes/footer.php            →      resources/views/layouts/app.blade.php

login.php                      →      resources/views/auth/login.blade.php
index.php                      →      resources/views/dashboard/index.blade.php

accounts/create.php           →      resources/views/accounts/create.blade.php
accounts/list.php             →      resources/views/accounts/index.blade.php
accounts/edit.php             →      resources/views/accounts/edit.blade.php
accounts/view.php             →      resources/views/accounts/show.blade.php
accounts/user-types.php       →      resources/views/user-types/index.blade.php

accounts/create-ajax.php      →      app/Http/Controllers/Api/AccountApiController.php
accounts/user-type-ajax.php   →      app/Http/Controllers/Api/UserTypeApiController.php

items/create.php              →      resources/views/items/create.blade.php
items/list.php                →      resources/views/items/index.blade.php
items/edit.php                →      resources/views/items/edit.blade.php

purchases/create.php          →      resources/views/purchases/create.blade.php
purchases/list.php            →      resources/views/purchases/index.blade.php
purchases/view.php            →      resources/views/purchases/show.blade.php

sales/create.php              →      resources/views/sales/create.blade.php
sales/list.php                →      resources/views/sales/index.blade.php
sales/view.php                →      resources/views/sales/show.blade.php

transactions/debit.php        →      resources/views/transactions/debit.blade.php
transactions/credit.php       →      resources/views/transactions/credit.blade.php
transactions/journal.php      →      resources/views/transactions/journal.blade.php
transactions/list.php         →      resources/views/transactions/index.blade.php

reports/*.php                 →      resources/views/reports/*.blade.php

assets/css/style.css          →      public/assets/css/style.css
assets/js/main.js             →      public/assets/js/main.js

database/schema.sql           →      database/migrations/*.php
```

## Controller Structure Example

```php
// app/Http/Controllers/AccountController.php
class AccountController extends Controller
{
    // GET /accounts - List all accounts
    public function index() { }
    
    // GET /accounts/create - Show create form
    public function create() { }
    
    // POST /accounts - Store new account
    public function store(Request $request) { }
    
    // GET /accounts/{id} - Show single account
    public function show(Account $account) { }
    
    // GET /accounts/{id}/edit - Show edit form
    public function edit(Account $account) { }
    
    // PUT /accounts/{id} - Update account
    public function update(Request $request, Account $account) { }
    
    // DELETE /accounts/{id} - Delete account
    public function destroy(Account $account) { }
}
```

## Route Structure Example

```php
// routes/web.php
Route::get('/accounts', [AccountController::class, 'index']);           // List
Route::get('/accounts/create', [AccountController::class, 'create']);    // Form
Route::post('/accounts', [AccountController::class, 'store']);           // Save
Route::get('/accounts/{account}', [AccountController::class, 'show']);    // View
Route::get('/accounts/{account}/edit', [AccountController::class, 'edit']); // Edit Form
Route::put('/accounts/{account}', [AccountController::class, 'update']); // Update
Route::delete('/accounts/{account}', [AccountController::class, 'destroy']); // Delete
```

## Model Structure Example

```php
// app/Models/Account.php
class Account extends Model
{
    protected $fillable = [...];
    
    // Relationships
    public function userType() { }
    public function purchases() { }
    public function sales() { }
    
    // Accessors/Mutators
    public function getDisplayNameAttribute() { }
}
```

## View Structure Example

```blade
{{-- resources/views/accounts/index.blade.php --}}
@extends('layouts.app')

@section('title', __('accounts'))

@section('content')
    <div class="page-header">
        <h1>{{ __('customer_list') }}</h1>
    </div>
    
    <div class="card">
        <div class="card-body">
            @foreach($accounts as $account)
                {{ $account->display_name }}
            @endforeach
        </div>
    </div>
@endsection
```

## Key Differences from Old Structure

1. **Separation of Concerns:**
   - Old: PHP files mix HTML, logic, and database queries
   - New: Models (data), Controllers (logic), Views (presentation)

2. **Routing:**
   - Old: Direct file access (`accounts/create.php`)
   - New: Route definitions (`/accounts/create` → Controller method)

3. **Database:**
   - Old: Raw SQL in PHP files
   - New: Eloquent ORM in Models

4. **Templates:**
   - Old: PHP with HTML mixed
   - New: Blade templates with clean syntax

5. **Assets:**
   - Old: `assets/` folder in root
   - New: `public/assets/` folder (web accessible)

6. **Configuration:**
   - Old: `config/config.php` with defines
   - New: `config/` files with arrays, `.env` for environment

## Naming Conventions

- **Controllers:** PascalCase, singular, `Controller` suffix
  - `AccountController`, `ItemController`

- **Models:** PascalCase, singular
  - `Account`, `Item`, `Purchase`

- **Views:** kebab-case, lowercase
  - `accounts/index.blade.php`, `user-types/index.blade.php`

- **Routes:** kebab-case, lowercase
  - `/accounts`, `/user-types`, `/party-ledger`

- **Migrations:** snake_case with timestamp
  - `2024_01_01_000001_create_users_table.php`


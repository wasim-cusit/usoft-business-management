<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class StockMovement extends Model
{
    protected $fillable = [
        'item_id',
        'movement_date',
        'movement_type',
        'reference_type',
        'reference_id',
        'quantity_in',
        'quantity_out',
        'rate',
        'balance_quantity',
    ];

    protected $casts = [
        'movement_date' => 'date',
        'quantity_in' => 'decimal:2',
        'quantity_out' => 'decimal:2',
        'rate' => 'decimal:2',
        'balance_quantity' => 'decimal:2',
    ];

    public $timestamps = false;
    const CREATED_AT = 'created_at';

    public function item(): BelongsTo
    {
        return $this->belongsTo(Item::class);
    }
}


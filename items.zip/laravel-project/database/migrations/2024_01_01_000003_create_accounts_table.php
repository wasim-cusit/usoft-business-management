<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('accounts', function (Blueprint $table) {
            $table->id();
            $table->string('account_code', 20)->unique()->nullable();
            $table->string('account_name', 100);
            $table->string('account_name_urdu', 100)->nullable();
            $table->enum('account_type', ['customer', 'supplier', 'both'])->default('customer');
            $table->foreignId('user_type_id')->nullable()->constrained('user_types')->nullOnDelete();
            $table->string('contact_person', 100)->nullable();
            $table->string('phone', 20)->nullable();
            $table->string('mobile', 20)->nullable();
            $table->string('email', 100)->nullable();
            $table->text('address')->nullable();
            $table->string('city', 50)->nullable();
            $table->decimal('opening_balance', 15, 2)->default(0.00);
            $table->enum('balance_type', ['debit', 'credit'])->default('debit');
            $table->enum('status', ['active', 'inactive'])->default('active');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('accounts');
    }
};


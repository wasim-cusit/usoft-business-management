<?php
require_once '../config/config.php';
requireLogin();

$pageTitle = 'all_sales_list';

$search = $_GET['search'] ?? '';
$dateFrom = $_GET['date_from'] ?? '';
$dateTo = $_GET['date_to'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$limit = RECORDS_PER_PAGE;
$offset = ($page - 1) * $limit;

try {
    $db = getDB();
    
    // Check if cash sale account exists, if not create it
    $stmt = $db->query("SELECT id FROM accounts WHERE account_name = 'Cash Sale' OR account_name_urdu = 'کیش فروخت' LIMIT 1");
    $cashAccount = $stmt->fetch();
    if (!$cashAccount) {
        // Create cash sale account
        try {
            $stmt = $db->prepare("INSERT INTO accounts (account_name, account_name_urdu, account_type, status) VALUES (?, ?, 'customer', 'active')");
            $stmt->execute(['Cash Sale', 'کیش فروخت']);
            $cashAccountId = $db->lastInsertId();
        } catch (PDOException $e) {
            // If creation fails, try to get existing one
            $stmt = $db->query("SELECT id FROM accounts WHERE account_name LIKE '%Cash%' OR account_name_urdu LIKE '%کیش%' LIMIT 1");
            $cashAccount = $stmt->fetch();
            $cashAccountId = $cashAccount ? $cashAccount['id'] : 0;
        }
    } else {
        $cashAccountId = $cashAccount['id'];
    }
    
    // Get customers and items for modal
    $stmt = $db->query("SELECT * FROM accounts WHERE account_type IN ('customer', 'both') AND status = 'active' ORDER BY account_name");
    $customers = $stmt->fetchAll();
    
    $stmt = $db->query("SELECT * FROM items WHERE status = 'active' ORDER BY item_name");
    $items = $stmt->fetchAll();
    
    $where = "WHERE 1=1";
    $params = [];
    
    if (!empty($search)) {
        $where .= " AND (s.sale_no LIKE ? OR a.account_name LIKE ?)";
        $searchParam = "%$search%";
        $params[] = $searchParam;
        $params[] = $searchParam;
    }
    
    if (!empty($dateFrom)) {
        $where .= " AND s.sale_date >= ?";
        $params[] = $dateFrom;
    }
    
    if (!empty($dateTo)) {
        $where .= " AND s.sale_date <= ?";
        $params[] = $dateTo;
    }
    
    // Get total count
    $stmt = $db->prepare("SELECT COUNT(*) as total FROM sales s LEFT JOIN accounts a ON s.account_id = a.id $where");
    $stmt->execute($params);
    $totalRecords = $stmt->fetch()['total'];
    $totalPages = ceil($totalRecords / $limit);
    
    // Get sales
    $paramsForQuery = $params;
    $paramsForQuery[] = $limit;
    $paramsForQuery[] = $offset;
    $stmt = $db->prepare("SELECT s.*, a.account_name, a.account_name_urdu, a.mobile, a.phone FROM sales s 
                         LEFT JOIN accounts a ON s.account_id = a.id 
                         $where ORDER BY s.id DESC LIMIT ? OFFSET ?");
    $stmt->execute($paramsForQuery);
    $sales = $stmt->fetchAll();
    
    // Calculate totals
    $stmt = $db->prepare("SELECT 
                            COALESCE(SUM(s.total_amount), 0) as total_amount,
                            COALESCE(SUM(s.discount), 0) as total_discount,
                            COALESCE(SUM(s.net_amount), 0) as total_net_amount,
                            COALESCE(SUM(s.paid_amount), 0) as total_paid_amount,
                            COALESCE(SUM(s.balance_amount), 0) as total_balance_amount
                         FROM sales s 
                         LEFT JOIN accounts a ON s.account_id = a.id 
                         $where");
    $stmt->execute($params);
    $totals = $stmt->fetch();
    $totalAmount = $totals['total_amount'] ?? 0;
    $totalDiscount = $totals['total_discount'] ?? 0;
    $totalNetAmount = $totals['total_net_amount'] ?? 0;
    $totalPaidAmount = $totals['total_paid_amount'] ?? 0;
    $totalBalanceAmount = $totals['total_balance_amount'] ?? 0;
    
} catch (PDOException $e) {
    $customers = [];
    $items = [];
    $sales = [];
    $totalPages = 0;
    $totalRecords = 0;
    $totalAmount = 0;
    $totalDiscount = 0;
    $totalNetAmount = 0;
    $totalPaidAmount = 0;
    $totalBalanceAmount = 0;
    $cashAccountId = 0;
}

include '../includes/header.php';
?>

<style>
/* Remove animations from card-header and card-body */
.card {
    transition: none !important;
}
.card:hover {
    transform: none !important;
}
.card-header {
    padding: 20px 25px !important;
    font-size: 18px !important;
    min-height: auto !important;
    height: auto !important;
}
.card-header .row {
    margin: 0 !important;
}
.card-header form {
    margin: 0 !important;
}
.card-header .form-control-sm {
    height: calc(1.5em + 0.5rem + 2px) !important;
}
.card-header .btn-sm {
    padding: 0.25rem 0.5rem !important;
    font-size: 0.875rem !important;
    line-height: 1.5 !important;
}
.card-body {
    animation: none !important;
}
.table tbody tr {
    transition: none !important;
}
.table tbody tr:hover {
    transform: none !important;
}
.btn {
    transition: none !important;
}
.btn:hover {
    transform: none !important;
}
/* Ensure footer displays in one row */
.table tfoot tr {
    display: table-row !important;
}
.table tfoot td {
    white-space: nowrap !important;
    vertical-align: middle !important;
}
/* Stock warning notification styling - clear background and text */
#saleFormMessage .alert-danger,
.modal .alert-danger {
    background-color: #f8d7da !important;
    border: 1px solid #f5c2c7 !important;
    color: #842029 !important;
    box-shadow: 0 4px 6px rgba(0,0,0,0.15) !important;
    opacity: 1 !important;
}
#saleFormMessage .alert-danger strong,
#saleFormMessage .alert-danger span,
#saleFormMessage .alert-danger small,
.modal .alert-danger strong,
.modal .alert-danger span,
.modal .alert-danger small {
    color: #842029 !important;
    font-weight: 600;
}
/* Success notification styling */
#saleFormMessage .alert-success,
.modal .alert-success {
    background-color: #d1e7dd !important;
    border: 1px solid #badbcc !important;
    color: #0f5132 !important;
    box-shadow: 0 4px 6px rgba(0,0,0,0.15) !important;
    opacity: 1 !important;
}
#saleFormMessage .alert-success strong,
#saleFormMessage .alert-success span,
.modal .alert-success strong,
.modal .alert-success span {
    color: #0f5132 !important;
}
</style>

<div class="page-header">
    <div class="d-flex justify-content-between align-items-center flex-wrap">
        <h1><i class="fas fa-cash-register"></i> <?php echo t('all_sales_list'); ?></h1>
        <button type="button" class="btn btn-primary mt-2 mt-md-0" data-bs-toggle="modal" data-bs-target="#newSaleModal">
            <i class="fas fa-plus"></i> <?php echo t('new_sale'); ?>
        </button>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <h5 class="mb-0"><?php echo t('all_sales_list'); ?> <span class="badge bg-primary"><?php echo $totalRecords ?? 0; ?></span></h5>
                    </div>
                    <div class="col-md-6">
                        <form method="GET" class="row g-2">
                            <div class="col-md-5">
                                <input type="text" class="form-control form-control-sm" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="<?php echo t('search'); ?>...">
                            </div>
                            <div class="col-md-3">
                                <input type="date" class="form-control form-control-sm" name="date_from" value="<?php echo htmlspecialchars($dateFrom); ?>" placeholder="<?php echo t('date_from'); ?>">
                            </div>
                            <div class="col-md-3">
                                <input type="date" class="form-control form-control-sm" name="date_to" value="<?php echo htmlspecialchars($dateTo); ?>" placeholder="<?php echo t('date_to'); ?>">
                            </div>
                            <div class="col-md-1">
                                <button type="submit" class="btn btn-primary btn-sm w-100">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th><?php echo t('bill_no'); ?></th>
                                <th><?php echo t('date'); ?></th>
                                <th><?php echo t('customer'); ?></th>
                                <th><?php echo t('total'); ?></th>
                                <th><?php echo t('discount'); ?></th>
                                <th><?php echo t('net_amount'); ?></th>
                                <th><?php echo t('paid_amount'); ?></th>
                                <th><?php echo t('balance'); ?></th>
                                <th><?php echo t('actions'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($sales)): ?>
                                <tr>
                                    <td colspan="9" class="text-center"><?php echo t('no_records'); ?></td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($sales as $sale): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($sale['sale_no'] ?? ''); ?></td>
                                        <td><?php echo formatDate($sale['sale_date']); ?></td>
                                        <td><?php echo displayAccountNameFull($sale); ?></td>
                                        <td><?php echo formatCurrency($sale['total_amount']); ?></td>
                                        <td><?php echo formatCurrency($sale['discount']); ?></td>
                                        <td><strong><?php echo formatCurrency($sale['net_amount']); ?></strong></td>
                                        <td><?php echo formatCurrency($sale['paid_amount']); ?></td>
                                        <td>
                                            <span class="badge <?php echo $sale['balance_amount'] > 0 ? 'bg-warning' : 'bg-success'; ?>">
                                                <?php echo formatCurrency($sale['balance_amount']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="<?php echo BASE_URL; ?>sales/view.php?id=<?php echo $sale['id']; ?>" class="btn btn-sm btn-info" title="<?php echo t('view'); ?>">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="<?php echo BASE_URL; ?>sales/edit.php?id=<?php echo $sale['id']; ?>" class="btn btn-sm btn-warning ms-1" title="<?php echo t('edit'); ?>">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="<?php echo BASE_URL; ?>sales/print.php?id=<?php echo $sale['id']; ?>" class="btn btn-sm btn-secondary ms-1" target="_blank" title="<?php echo t('print'); ?>">
                                                <i class="fas fa-print"></i>
                                            </a>
                                            <button type="button" class="btn btn-sm btn-success whatsapp-share-btn ms-1" 
                                                    data-sale-id="<?php echo $sale['id']; ?>" 
                                                    data-sale-no="<?php echo htmlspecialchars($sale['sale_no']); ?>"
                                                    data-mobile="<?php echo htmlspecialchars($sale['mobile'] ?? ''); ?>"
                                                    data-phone="<?php echo htmlspecialchars($sale['phone'] ?? ''); ?>"
                                                    title="<?php echo t('share_via_whatsapp'); ?>">
                                                <i class="fab fa-whatsapp"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-danger delete-sale-btn ms-1" data-sale-id="<?php echo $sale['id']; ?>" data-sale-no="<?php echo htmlspecialchars($sale['sale_no']); ?>" title="<?php echo t('delete'); ?>">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr class="table-info">
                                <td colspan="3" class="text-end" style="white-space: nowrap;"><strong><?php echo t('total'); ?>:</strong></td>
                                <td class="text-end" style="white-space: nowrap;"><strong><?php echo formatCurrency($totalAmount); ?></strong></td>
                                <td class="text-end" style="white-space: nowrap;"><strong><?php echo formatCurrency($totalDiscount); ?></strong></td>
                                <td class="text-end" style="white-space: nowrap;"><strong><?php echo formatCurrency($totalNetAmount); ?></strong></td>
                                <td class="text-end" style="white-space: nowrap;"><strong><?php echo formatCurrency($totalPaidAmount); ?></strong></td>
                                <td class="text-end" style="white-space: nowrap;">
                                    <span class="badge <?php echo $totalBalanceAmount > 0 ? 'bg-warning' : 'bg-success'; ?>">
                                        <strong><?php echo formatCurrency($totalBalanceAmount); ?></strong>
                                    </span>
                                </td>
                                <td></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                
                <?php if ($totalPages > 1): ?>
                    <nav aria-label="<?php echo t('page_navigation'); ?>">
                        <ul class="pagination justify-content-center">
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&date_from=<?php echo urlencode($dateFrom); ?>&date_to=<?php echo urlencode($dateTo); ?>"><?php echo t('previous'); ?></a>
                                </li>
                            <?php endif; ?>
                            
                            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&date_from=<?php echo urlencode($dateFrom); ?>&date_to=<?php echo urlencode($dateTo); ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                            
                            <?php if ($page < $totalPages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&date_from=<?php echo urlencode($dateFrom); ?>&date_to=<?php echo urlencode($dateTo); ?>"><?php echo t('next'); ?></a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- New Sale Modal -->
<div class="modal fade" id="newSaleModal" tabindex="-1" aria-labelledby="newSaleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="newSaleModalLabel">
                    <i class="fas fa-cash-register"></i> <?php echo t('add_sale'); ?>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="saleFormMessage"></div>
                <form id="newSaleForm">
                    <div class="row align-items-end">
                        <div class="col-md-2 mb-3">
                            <label class="form-label"><?php echo t('date'); ?> <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" name="sale_date" id="sale_date" value="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('customer'); ?> <span class="text-danger">*</span></label>
                            <select class="form-select" name="account_id" id="sale_account_id" required>
                                <option value="">-- <?php echo t('select'); ?> --</option>
                                <option value="<?php echo $cashAccountId ?? 0; ?>" style="font-weight: bold; color: #0d6efd;">
                                    <?php echo t('cash_sale'); ?>
                                </option>
                                <?php 
                                foreach ($customers as $customer): 
                                    // Skip cash account if it's already in the list
                                    if (isset($cashAccountId) && $customer['id'] == $cashAccountId) continue;
                                ?>
                                    <option value="<?php echo $customer['id']; ?>">
                                        <?php echo displayAccountNameFull($customer); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <?php /*
                        <div class="col-md-2 mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="sale_cash_on_sale" name="cash_on_sale">
                                <label class="form-check-label" for="sale_cash_on_sale">
                                    <?php echo t('cash_on_sale'); ?>
                                </label>
                            </div>
                        </div>
                        */ ?>
                        
                        <?php /* Commented out Remarks field - user requested
                        <div class="col-md-4 mb-3">
                            <label class="form-label"><?php echo t('remarks'); ?></label>
                            <input type="text" class="form-control" name="remarks" id="sale_remarks">
                        </div>
                        */ ?>
                    </div>
                    
                    <div class="mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h6 class="mb-0"><strong><?php echo t('items'); ?></strong></h6>
                            <button type="button" class="btn btn-sm btn-success" id="addSaleRow">
                                <i class="fas fa-plus"></i> <?php echo t('add'); ?>
                            </button>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-bordered table-sm">
                                <thead class="table-light">
                                    <tr>
                                        <th><?php echo t('item_name'); ?></th>
                                        <th width="18%"><?php echo t('quantity'); ?></th>
                                        <th width="18%"><?php echo t('rate'); ?></th>
                                        <th width="18%"><?php echo t('amount'); ?></th>
                                        <th width="8%"><?php echo t('actions'); ?></th>
                                    </tr>
                                </thead>
                                <tbody id="saleItemsBody">
                                    <tr>
                                        <td>
                                            <select class="form-select form-select-sm sale-item-select" name="item_id[]" required>
                                                <option value="">-- <?php echo t('select'); ?> --</option>
                                                <?php foreach ($items as $item): ?>
                                                    <option value="<?php echo $item['id']; ?>" data-rate="<?php echo $item['sale_rate']; ?>" data-stock="<?php echo $item['current_stock']; ?>">
                                                        <?php echo htmlspecialchars($item['item_name'] ?? ''); ?> (<?php echo t('stock_label'); ?>: <?php echo formatStock($item['current_stock']); ?>)
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </td>
                                        <td><input type="number" step="0.01" class="form-control form-control-sm sale-quantity" name="quantity[]" required></td>
                                        <td><input type="number" step="0.01" class="form-control form-control-sm sale-rate" name="rate[]" required></td>
                                        <td><input type="text" class="form-control form-control-sm sale-amount" readonly></td>
                                        <td><button type="button" class="btn btn-danger btn-sm remove-sale-row" disabled><i class="fas fa-times"></i></button></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('total'); ?></label>
                            <input type="text" class="form-control" id="sale_total_amount" readonly>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('discount'); ?></label>
                            <input type="number" step="0.01" class="form-control" name="discount" id="sale_discount" placeholder="0">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('net_amount'); ?></label>
                            <input type="text" class="form-control" id="sale_net_amount" readonly>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo t('receipt'); ?></label>
                            <input type="number" step="0.01" class="form-control" name="paid_amount" id="sale_paid_amount" placeholder="0">
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label"><?php echo t('balance'); ?></label>
                            <input type="text" class="form-control" id="sale_balance_amount" readonly>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="fas fa-times"></i> <?php echo t('cancel'); ?>
                </button>
                <button type="button" class="btn btn-primary" onclick="saveNewSale()">
                    <i class="fas fa-save"></i> <?php echo t('save'); ?>
                </button>
            </div>
        </div>
    </div>
</div>

<script>
// Wait for DOM to be ready
document.addEventListener('DOMContentLoaded', function() {
// Add new row
const addSaleRowEl = document.getElementById('addSaleRow');
if (addSaleRowEl) {
    addSaleRowEl.addEventListener('click', function() {
        const tbody = document.getElementById('saleItemsBody');
        if (tbody) {
            const firstRow = tbody.querySelector('tr');
            if (firstRow) {
                const newRow = firstRow.cloneNode(true);
                
                // Clear values
                const itemSelect = newRow.querySelector('.sale-item-select');
                const quantity = newRow.querySelector('.sale-quantity');
                const rate = newRow.querySelector('.sale-rate');
                const amount = newRow.querySelector('.sale-amount');
                const removeBtn = newRow.querySelector('.remove-sale-row');
                
                if (itemSelect) itemSelect.value = '';
                if (quantity) quantity.value = '';
                if (rate) rate.value = '';
                if (amount) amount.value = '';
                if (removeBtn) removeBtn.disabled = false;
                
                // Insert new row at the top instead of bottom
                tbody.insertBefore(newRow, firstRow);
                updateSaleRemoveButtons();
            }
        }
    });
}

// Remove row
document.addEventListener('click', function(e) {
    if (e.target.closest('.remove-sale-row')) {
        const tbody = document.getElementById('saleItemsBody');
        if (tbody.querySelectorAll('tr').length > 1) {
            e.target.closest('tr').remove();
            calculateSaleTotal();
            updateSaleRemoveButtons();
        }
    }
});

// Update remove buttons state
function updateSaleRemoveButtons() {
    const rows = document.querySelectorAll('#saleItemsBody tr');
    rows.forEach((row, index) => {
        const btn = row.querySelector('.remove-sale-row');
        btn.disabled = rows.length === 1;
    });
}

// Calculate row amount
document.addEventListener('input', function(e) {
    if (e.target.classList.contains('sale-quantity') || e.target.classList.contains('sale-rate')) {
        const row = e.target.closest('tr');
        calculateSaleRowAmount(row);
    }
});

// Check stock when quantity changes - show warning but allow
document.addEventListener('input', function(e) {
    if (e.target.classList.contains('sale-quantity')) {
        const row = e.target.closest('tr');
        const qty = parseFloat(e.target.value) || 0;
        const itemSelect = row.querySelector('.sale-item-select');
        const selectedOption = itemSelect?.options[itemSelect?.selectedIndex];
        const stock = parseFloat(selectedOption?.dataset.stock) || 0;
        const itemName = itemSelect.options[itemSelect.selectedIndex]?.text.split(' (')[0] || '';
        
        // Show warning if stock is low but don't block - show in top-right notification only
        if (qty > stock && qty > 0) {
            const shortage = qty - stock;
            const warningMsg = itemName + ' - <?php echo t('available_stock'); ?>: ' + stock + ', <?php echo t('required_quantity'); ?>: ' + qty + ', <?php echo t('stock_shortage'); ?>: ' + shortage;
            showNotification('<?php echo t('stock_warning'); ?>: ' + warningMsg, 'error', 5000);
        }
        calculateSaleRowAmount(row);
    }
});

<?php /* Commented out rate placeholder - user requested to remove automatic rate display
// Helper function to format rate for placeholder (remove .00 for whole numbers)
function formatRatePlaceholder(rate) {
    if (!rate) return '';
    const numRate = parseFloat(rate);
    if (isNaN(numRate)) return rate;
    if (numRate === 0) return '0';
    if (numRate % 1 === 0) {
        // Whole number - remove decimals
        return numRate.toString();
    } else {
        // Has decimals - show with 2 decimal places
        return numRate.toFixed(2);
    }
}
*/ ?>

// Set rate placeholder when item selected - user must enter manually
document.addEventListener('change', function(e) {
    if (e.target.classList.contains('sale-item-select')) {
        const row = e.target.closest('tr');
        const selectedOption = e.target.options[e.target.selectedIndex];
        const rate = selectedOption.dataset.rate;
        const stock = selectedOption.dataset.stock;
        const rateInput = row.querySelector('.sale-rate');
        
        // Clear the rate field - user must manually enter the rate
        // Commented out automatic rate placeholder - user requested
        rateInput.value = ''; // Clear any existing value
        rateInput.setAttribute('placeholder', ''); // No placeholder - user must enter manually
        
        <?php /* Commented out - user requested to remove automatic rate display
        if (rate) {
            rateInput.value = ''; // Clear any existing value
            rateInput.setAttribute('placeholder', formatRatePlaceholder(rate)); // Show rate as placeholder suggestion (formatted)
        } else {
            rateInput.setAttribute('placeholder', '');
        }
        */ ?>
        
        if (stock !== undefined) {
            row.querySelector('.sale-quantity').setAttribute('max', stock);
        }
        
        // Clear amount when item changes
        row.querySelector('.sale-amount').value = '';
    }
});

// Allow manual rate entry and recalculate
document.addEventListener('input', function(e) {
    if (e.target.classList.contains('sale-rate')) {
        const row = e.target.closest('tr');
        if (e.target.value) {
            calculateSaleRowAmount(row);
        }
    }
});

document.addEventListener('blur', function(e) {
    if (e.target.classList.contains('sale-rate')) {
        const row = e.target.closest('tr');
        if (e.target.value) {
            calculateSaleRowAmount(row);
        }
    }
});

function calculateSaleRowAmount(row) {
    const qty = parseFloat(row.querySelector('.sale-quantity').value) || 0;
    const rate = parseFloat(row.querySelector('.sale-rate').value) || 0;
    const amount = qty * rate;
    row.querySelector('.sale-amount').value = formatNumber(amount);
    calculateSaleTotal();
}

function calculateSaleTotal() {
    let total = 0;
    document.querySelectorAll('.sale-amount').forEach(function(input) {
        total += parseFloat(String(input.value).replace(/,/g, '')) || 0;
    });
    
    const totalAmountEl = document.getElementById('sale_total_amount');
    if (totalAmountEl) {
        totalAmountEl.value = formatNumber(total);
    }
    
    const discountEl = document.getElementById('sale_discount');
    const discount = discountEl ? parseFloat(String(discountEl.value).replace(/,/g, '')) || 0 : 0;
    const netAmount = total - discount;
    
    const netAmountEl = document.getElementById('sale_net_amount');
    if (netAmountEl) {
        netAmountEl.value = formatNumber(netAmount);
    }
    
    const paidAmountEl = document.getElementById('sale_paid_amount');
    const paid = paidAmountEl ? parseFloat(String(paidAmountEl.value).replace(/,/g, '')) || 0 : 0;
    const balance = netAmount - paid;
    
    const balanceAmountEl = document.getElementById('sale_balance_amount');
    if (balanceAmountEl) {
        balanceAmountEl.value = formatNumber(balance);
    }
}

// Calculate totals when discount or paid amount changes
const saleDiscountEl = document.getElementById('sale_discount');
if (saleDiscountEl) {
    saleDiscountEl.addEventListener('input', function() {
        calculateSaleTotal();
        // Update paid amount if cash on sale is checked
        const cashOnSaleCheckbox = document.getElementById('sale_cash_on_sale');
        if (cashOnSaleCheckbox && cashOnSaleCheckbox.checked) {
            setTimeout(function() {
                const netAmount = parseFloat(String(document.getElementById('sale_net_amount').value).replace(/,/g, '')) || 0;
                const paidAmountEl = document.getElementById('sale_paid_amount');
                if (paidAmountEl) {
                    paidAmountEl.value = formatNumber(netAmount);
                }
                calculateSaleTotal();
            }, 100);
        }
    });
}

const salePaidAmountEl = document.getElementById('sale_paid_amount');
if (salePaidAmountEl) {
    salePaidAmountEl.addEventListener('input', calculateSaleTotal);
}

// Handle customer selection - auto-check cash on sale for cash sale account
const saleAccountIdEl = document.getElementById('sale_account_id');
if (saleAccountIdEl) {
    saleAccountIdEl.addEventListener('change', function() {
        const selectedValue = this.value;
        const cashAccountId = <?php echo $cashAccountId ?? 0; ?>;
        const cashOnSaleCheckbox = document.getElementById('sale_cash_on_sale');
        
        if (selectedValue == cashAccountId && cashAccountId > 0 && cashOnSaleCheckbox) {
            // Auto-check cash on sale for cash sale account
            cashOnSaleCheckbox.checked = true;
            // Auto-fill paid amount
            setTimeout(function() {
                const netAmount = parseFloat(String(document.getElementById('sale_net_amount').value).replace(/,/g, '')) || 0;
                const paidAmountEl = document.getElementById('sale_paid_amount');
                if (paidAmountEl) {
                    paidAmountEl.value = formatNumber(netAmount);
                }
                calculateSaleTotal();
            }, 100);
        }
    });
}

// Handle cash on sale checkbox
const saleCashOnSaleEl = document.getElementById('sale_cash_on_sale');
if (saleCashOnSaleEl) {
    saleCashOnSaleEl.addEventListener('change', function() {
        if (this.checked) {
            // Set paid amount equal to net amount
            const netAmountEl = document.getElementById('sale_net_amount');
            const paidAmountEl = document.getElementById('sale_paid_amount');
            if (netAmountEl && paidAmountEl) {
                const netAmount = parseFloat(netAmountEl.value) || 0;
                paidAmountEl.value = formatNumber(netAmount);
            }
            calculateSaleTotal();
        } else {
            // Clear paid amount if unchecked
            const paidAmountEl = document.getElementById('sale_paid_amount');
            if (paidAmountEl) {
                paidAmountEl.value = '';
            }
            calculateSaleTotal();
        }
    });
}

// Save new sale - make it globally accessible
window.saveNewSale = function() {
    const form = document.getElementById('newSaleForm');
    if (!form) return;
    
    const formData = new FormData(form);
    const messageDiv = document.getElementById('saleFormMessage');
    
    // Clear previous messages in modal (but notifications will show in top-right)
    if (messageDiv) {
        messageDiv.innerHTML = '';
    }
    
    // Validate required fields
    if (!formData.get('account_id')) {
        showNotification('<?php echo t('please_select_customer'); ?>', 'error', 5000);
        return;
    }
    
    // Validate items
    const itemIds = formData.getAll('item_id[]');
    const quantities = formData.getAll('quantity[]');
    const rates = formData.getAll('rate[]');
    
    let hasValidItem = false;
    for (let i = 0; i < itemIds.length; i++) {
        if (itemIds[i] && quantities[i] && rates[i]) {
            hasValidItem = true;
            break;
        }
    }
    
    if (!hasValidItem) {
        showNotification('<?php echo t('please_add_item'); ?>', 'error', 5000);
        return;
    }
    
    // Get save button - find it by selector since event.target is not available
    const saveBtn = document.querySelector('#newSaleModal .btn-primary[onclick*="saveNewSale"]');
    const originalText = saveBtn ? saveBtn.innerHTML : '';
    if (saveBtn) {
        saveBtn.disabled = true;
        saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <?php echo t('save'); ?>...';
    }
    
    fetch('<?php echo BASE_URL; ?>sales/create-ajax.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Close modal immediately
            const modal = bootstrap.Modal.getInstance(document.getElementById('newSaleModal'));
            modal.hide();
            
            // Reset form
            form.reset();
            
            // Show warning if there are stock warnings - in top-right notification only
            if (data.warnings && data.warnings.length > 0) {
                let warningMsg = '<?php echo t('stock_warning'); ?>: ';
                data.warnings.forEach(function(warning, index) {
                    if (index > 0) warningMsg += ', ';
                    warningMsg += warning.item_name + ' (<?php echo t('available_stock'); ?>: ' + warning.available_stock + 
                        ', <?php echo t('required_quantity'); ?>: ' + warning.required_quantity + 
                        ', <?php echo t('stock_shortage'); ?>: ' + warning.shortage + ')';
                });
                // Show error notification for stock warnings (red/danger style)
                showNotification(data.message + ' - ' + warningMsg, 'error', 5000);
            } else {
                // Show success notification
                showNotification(data.message, 'success', 3000);
            }
            
            // Reload after 2 seconds to show notification
            setTimeout(() => {
                location.reload();
            }, 2000);
        } else {
            // Show error in top-right notification only
            showNotification(data.message, 'error', 5000);
            if (saveBtn) {
                saveBtn.disabled = false;
                saveBtn.innerHTML = originalText;
            }
        }
    })
    .catch(error => {
        // Show error in top-right notification only
        showNotification('<?php echo t('error_adding_sale'); ?>', 'error', 5000);
        if (saveBtn) {
            saveBtn.disabled = false;
            saveBtn.innerHTML = originalText;
        }
    });
}

// Reset form on modal close
const newSaleModalEl = document.getElementById('newSaleModal');
if (newSaleModalEl) {
    newSaleModalEl.addEventListener('hidden.bs.modal', function() {
        const newSaleFormEl = document.getElementById('newSaleForm');
        if (newSaleFormEl) {
            newSaleFormEl.reset();
        }
        const saleFormMessageEl = document.getElementById('saleFormMessage');
        if (saleFormMessageEl) {
            saleFormMessageEl.innerHTML = '';
        }
        const tbody = document.getElementById('saleItemsBody');
        if (tbody) {
            while (tbody.children.length > 1) {
                tbody.removeChild(tbody.lastChild);
            }
            const itemSelect = tbody.querySelector('.sale-item-select');
            const quantity = tbody.querySelector('.sale-quantity');
            const rate = tbody.querySelector('.sale-rate');
            const amount = tbody.querySelector('.sale-amount');
            if (itemSelect) itemSelect.value = '';
            if (quantity) quantity.value = '';
            if (rate) rate.value = '';
            if (amount) amount.value = '';
        }
        const saleDateEl = document.getElementById('sale_date');
        if (saleDateEl) {
            saleDateEl.value = '<?php echo date('Y-m-d'); ?>';
        }
        calculateSaleTotal();
        updateSaleRemoveButtons();
    });
}

// Initialize - only if elements exist
const saleItemsBodyEl = document.getElementById('saleItemsBody');
if (saleItemsBodyEl) {
    updateSaleRemoveButtons();
    calculateSaleTotal();
}

// Delete sale functionality - use event delegation
document.addEventListener('click', function(e) {
    if (e.target.closest('.delete-sale-btn')) {
        const btn = e.target.closest('.delete-sale-btn');
        const saleId = btn.getAttribute('data-sale-id');
        const saleNo = btn.getAttribute('data-sale-no');
        
        if (confirm('<?php echo t('are_you_sure_delete'); ?> Sale "' + saleNo + '"?')) {
            // Show loading
            btn.disabled = true;
            const originalHtml = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            
            fetch('<?php echo BASE_URL; ?>sales/delete-ajax.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'id=' + saleId
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showNotification(data.message, 'success');
                    setTimeout(() => {
                        location.reload();
                    }, 1000);
                } else {
                    showNotification(data.message, 'error');
                    btn.disabled = false;
                    btn.innerHTML = originalHtml;
                }
            })
            .catch(error => {
                showNotification('<?php echo t('error_deleting_sale'); ?>', 'error');
                btn.disabled = false;
                btn.innerHTML = originalHtml;
            });
        }
    }
});
}); // End DOMContentLoaded

// Save new sale - defined outside DOMContentLoaded to be accessible globally
window.saveNewSale = function() {
    const form = document.getElementById('newSaleForm');
    if (!form) return;
    
    const formData = new FormData(form);
    const messageDiv = document.getElementById('saleFormMessage');
    
    // Clear previous messages in modal (but notifications will show in top-right)
    if (messageDiv) {
        messageDiv.innerHTML = '';
    }
    
    // Validate required fields
    if (!formData.get('account_id')) {
        showNotification('<?php echo t('please_select_customer'); ?>', 'error', 5000);
        return;
    }
    
    // Validate items
    const itemIds = formData.getAll('item_id[]');
    const quantities = formData.getAll('quantity[]');
    const rates = formData.getAll('rate[]');
    
    let hasValidItem = false;
    for (let i = 0; i < itemIds.length; i++) {
        if (itemIds[i] && quantities[i] && rates[i]) {
            hasValidItem = true;
            break;
        }
    }
    
    if (!hasValidItem) {
        showNotification('<?php echo t('please_add_item'); ?>', 'error', 5000);
        return;
    }
    
    // Get save button - find it by selector since event.target is not available
    const saveBtn = document.querySelector('#newSaleModal .btn-primary[onclick*="saveNewSale"]');
    const originalText = saveBtn ? saveBtn.innerHTML : '';
    if (saveBtn) {
        saveBtn.disabled = true;
        saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <?php echo t('save'); ?>...';
    }
    
    fetch('<?php echo BASE_URL; ?>sales/create-ajax.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Close modal immediately
            const modal = bootstrap.Modal.getInstance(document.getElementById('newSaleModal'));
            modal.hide();
            
            // Reset form
            form.reset();
            
            // Show warning if there are stock warnings - in top-right notification only
            if (data.warnings && data.warnings.length > 0) {
                let warningMsg = '<?php echo t('stock_warning'); ?>: ';
                data.warnings.forEach(function(warning, index) {
                    if (index > 0) warningMsg += ', ';
                    warningMsg += warning.item_name + ' (<?php echo t('available_stock'); ?>: ' + warning.available_stock + 
                        ', <?php echo t('required_quantity'); ?>: ' + warning.required_quantity + 
                        ', <?php echo t('stock_shortage'); ?>: ' + warning.shortage + ')';
                });
                // Show error notification for stock warnings (red/danger style)
                showNotification(data.message + ' - ' + warningMsg, 'error', 5000);
            } else {
                // Show success notification
                showNotification(data.message, 'success', 3000);
            }
            
            // Reload after 2 seconds to show notification
            setTimeout(() => {
                location.reload();
            }, 2000);
        } else {
            // Show error in top-right notification only
            showNotification(data.message, 'error', 5000);
            if (saveBtn) {
                saveBtn.disabled = false;
                saveBtn.innerHTML = originalText;
            }
        }
    })
    .catch(error => {
        // Show error in top-right notification only
        showNotification('<?php echo t('error_adding_sale'); ?>', 'error', 5000);
        if (saveBtn) {
            saveBtn.disabled = false;
            saveBtn.innerHTML = originalText;
        }
    });
};

// WhatsApp share functionality
document.addEventListener('click', function(e) {
    if (e.target.closest('.whatsapp-share-btn')) {
        const btn = e.target.closest('.whatsapp-share-btn');
        const saleId = btn.getAttribute('data-sale-id');
        const saleNo = btn.getAttribute('data-sale-no');
        const mobile = btn.getAttribute('data-mobile') || '';
        const phone = btn.getAttribute('data-phone') || '';
        const phoneNumber = mobile || phone;
        
        document.getElementById('whatsapp_sale_id').value = saleId;
        document.getElementById('whatsapp_sale_no').textContent = saleNo;
        
        // Show modal
        const modal = new bootstrap.Modal(document.getElementById('whatsappShareModal'));
        modal.show();
        
        // Set phone number if available (after modal is shown)
        setTimeout(() => {
            const phoneInput = document.getElementById('whatsapp_phone');
            if (phoneInput) {
                // Remove any existing mask
                if (phoneInput.inputmask) {
                    phoneInput.inputmask.remove();
                }
                // Set phone number if available, otherwise clear
                if (phoneNumber) {
                    phoneInput.value = phoneNumber;
                } else {
                    phoneInput.value = '';
                }
                phoneInput.focus();
            }
        }, 100);
    }
});

// Handle WhatsApp share button in modal using event delegation
document.addEventListener('click', function(e) {
    if (e.target.closest('#whatsappShareBtn')) {
        e.preventDefault();
        e.stopPropagation();
        
        const phoneInput = document.getElementById('whatsapp_phone');
        if (!phoneInput) {
            alert('<?php echo t('please_enter_phone_number'); ?>');
            return;
        }
        
        // Get phone number (remove any non-digit characters except +)
        let phoneNumber = phoneInput.value.trim().replace(/[^0-9+]/g, '');
        
        const saleId = document.getElementById('whatsapp_sale_id').value;
        
        if (!phoneNumber || phoneNumber.length < 10) {
            alert('<?php echo t('please_enter_phone_number'); ?>');
            return;
        }
        
        // Format phone number: ensure it starts with +92
        let cleanPhone = phoneNumber;
        if (cleanPhone.startsWith('0')) {
            // Local format: 03001234567 -> +923001234567
            cleanPhone = '+92' + cleanPhone.substring(1);
        } else if (cleanPhone.startsWith('92') && !cleanPhone.startsWith('+92')) {
            // 92XXXXXXXXXX -> +92XXXXXXXXXX
            cleanPhone = '+' + cleanPhone;
        } else if (!cleanPhone.startsWith('+')) {
            // If no country code, assume Pakistan
            cleanPhone = '+92' + cleanPhone;
        }
        
        // Validate phone number (should be 13 characters: +92XXXXXXXXXX)
        if (cleanPhone.length < 13 || !cleanPhone.startsWith('+92')) {
            alert('<?php echo t('invalid_phone_number'); ?>');
            return;
        }
        
        // Disable button during fetch
        const btn = e.target.closest('#whatsappShareBtn');
        const originalText = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <?php echo t('sending'); ?>...';
        
        // Fetch invoice details
        fetch('<?php echo BASE_URL; ?>sales/whatsapp-details-ajax.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'id=' + encodeURIComponent(saleId)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                // Open WhatsApp with message (remove + from phone number for wa.me)
                const whatsappUrl = 'https://wa.me/' + cleanPhone.substring(1) + '?text=' + encodeURIComponent(data.message);
                window.open(whatsappUrl, '_blank');
                
                // Close modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('whatsappShareModal'));
                if (modal) {
                    modal.hide();
                }
                // Reset button
                btn.disabled = false;
                btn.innerHTML = originalText;
            } else {
                alert(data.message || '<?php echo t('error_fetching_invoice'); ?>');
                btn.disabled = false;
                btn.innerHTML = originalText;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('<?php echo t('error_fetching_invoice'); ?>');
            btn.disabled = false;
            btn.innerHTML = originalText;
        });
    }
});
</script>

<!-- WhatsApp Share Modal -->
<div class="modal fade" id="whatsappShareModal" tabindex="-1" aria-labelledby="whatsappShareModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="whatsappShareModalLabel">
                    <i class="fab fa-whatsapp text-success"></i> <?php echo t('share_via_whatsapp'); ?>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p><?php echo t('invoice'); ?>: <strong id="whatsapp_sale_no"></strong></p>
                <div class="mb-3">
                    <label for="whatsapp_phone" class="form-label"><?php echo t('phone_number'); ?> <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="whatsapp_phone" placeholder="<?php echo t('enter_phone_number'); ?>" required>
                    <small class="form-text text-muted"><?php echo t('format'); ?>: +92-300-0000000</small>
                </div>
                <input type="hidden" id="whatsapp_sale_id" value="">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                <button type="button" class="btn btn-success" id="whatsappShareBtn">
                    <i class="fab fa-whatsapp"></i> <?php echo t('send'); ?>
                </button>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>


<?php

namespace App\Http\Controllers;

use App\Models\Item;
use Illuminate\Http\Request;

class ItemController extends Controller
{
    /**
     * Display a listing of items
     */
    public function index(Request $request)
    {
        $query = Item::query();
        
        // Search functionality
        if ($request->has('search') && $request->search) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('item_name', 'like', "%{$search}%")
                  ->orWhere('item_name_urdu', 'like', "%{$search}%")
                  ->orWhere('item_code', 'like', "%{$search}%");
            });
        }
        
        // Filter by status
        if ($request->has('status') && $request->status !== '') {
            $query->where('status', $request->status);
        } else {
            $query->where('status', 'active');
        }
        
        $items = $query->orderBy('id', 'desc')->paginate(20);
        
        return view('items.index', compact('items'));
    }
    
    /**
     * Show the form for creating a new item
     */
    public function create()
    {
        return view('items.create');
    }
    
    /**
     * Store a newly created item
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'item_name' => 'required|string|max:100',
            'item_name_urdu' => 'nullable|string|max:100',
            'item_code' => 'nullable|string|max:50|unique:items,item_code',
            'category' => 'nullable|string|max:50',
            'unit' => 'required|string|max:20',
            'purchase_rate' => 'nullable|numeric|min:0',
            'sale_rate' => 'nullable|numeric|min:0',
            'opening_stock' => 'nullable|numeric|min:0',
            'current_stock' => 'nullable|numeric|min:0',
            'min_stock' => 'nullable|numeric|min:0',
            'description' => 'nullable|string',
            'status' => 'required|in:active,inactive',
        ]);
        
        // Generate item code if not provided
        if (empty($validated['item_code'])) {
            $lastItem = Item::orderBy('id', 'desc')->first();
            $lastId = $lastItem ? $lastItem->id : 0;
            $validated['item_code'] = generateCode('ITM', $lastId);
        }
        
        // Set current_stock to opening_stock if not provided
        if (!isset($validated['current_stock']) && isset($validated['opening_stock'])) {
            $validated['current_stock'] = $validated['opening_stock'];
        }
        
        Item::create($validated);
        
        return redirect()->route('items.index')
            ->with('success', __('item_added_success'));
    }
    
    /**
     * Show the form for editing the specified item
     */
    public function edit(Item $item)
    {
        return view('items.edit', compact('item'));
    }
    
    /**
     * Update the specified item
     */
    public function update(Request $request, Item $item)
    {
        $validated = $request->validate([
            'item_name' => 'required|string|max:100',
            'item_name_urdu' => 'nullable|string|max:100',
            'item_code' => 'nullable|string|max:50|unique:items,item_code,' . $item->id,
            'category' => 'nullable|string|max:50',
            'unit' => 'required|string|max:20',
            'purchase_rate' => 'nullable|numeric|min:0',
            'sale_rate' => 'nullable|numeric|min:0',
            'opening_stock' => 'nullable|numeric|min:0',
            'current_stock' => 'nullable|numeric|min:0',
            'min_stock' => 'nullable|numeric|min:0',
            'description' => 'nullable|string',
            'status' => 'required|in:active,inactive',
        ]);
        
        $item->update($validated);
        
        return redirect()->route('items.index')
            ->with('success', __('item_updated_success'));
    }
    
    /**
     * Remove the specified item
     */
    public function destroy(Item $item)
    {
        // Check if item has been used in purchases or sales
        if ($item->purchaseItems()->count() > 0 || $item->saleItems()->count() > 0) {
            return redirect()->route('items.index')
                ->with('error', __('cannot_delete_item_in_use'));
        }
        
        $item->delete();
        
        return redirect()->route('items.index')
            ->with('success', __('item_deleted_success'));
    }
}


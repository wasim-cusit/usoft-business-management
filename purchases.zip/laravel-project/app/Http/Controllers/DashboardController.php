<?php

namespace App\Http\Controllers;

use App\Models\Account;
use App\Models\Item;
use App\Models\Purchase;
use App\Models\Sale;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $dateFrom = $request->get('date_from', now()->format('Y-m-d'));
        $dateTo = $request->get('date_to', now()->format('Y-m-d'));
        
        // Sales Statistics
        $salesStats = Sale::whereBetween('sale_date', [$dateFrom, $dateTo])
            ->selectRaw('
                COALESCE(SUM(net_amount), 0) as total_sales,
                COALESCE(SUM(paid_amount), 0) as credit_sales,
                COALESCE(SUM(balance_amount), 0) as debit_amount
            ')
            ->first();
        
        // Purchases Statistics
        $purchaseStats = Purchase::whereBetween('purchase_date', [$dateFrom, $dateTo])
            ->selectRaw('
                COALESCE(SUM(net_amount), 0) as total_purchases,
                COALESCE(SUM(paid_amount), 0) as credit_purchases,
                COALESCE(SUM(balance_amount), 0) as debit_purchases
            ')
            ->first();
        
        // Total Accounts
        $totalAccounts = Account::where('status', 'active')->count();
        
        // Total Items
        $totalItems = Item::where('status', 'active')->count();
        
        // Low Stock Items
        $lowStock = Item::where('status', 'active')
            ->whereRaw('current_stock <= min_stock')
            ->count();
        
        return view('dashboard.index', compact(
            'salesStats',
            'purchaseStats',
            'totalAccounts',
            'totalItems',
            'lowStock',
            'dateFrom',
            'dateTo'
        ));
    }
}


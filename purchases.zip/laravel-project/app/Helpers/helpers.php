<?php

if (!function_exists('formatCurrency')) {
    function formatCurrency($amount)
    {
        return 'Rs. ' . number_format($amount, 2);
    }
}

if (!function_exists('formatDate')) {
    function formatDate($date)
    {
        if (empty($date)) {
            return '';
        }
        return \Carbon\Carbon::parse($date)->format('d-m-Y');
    }
}

if (!function_exists('displayAccountName')) {
    function displayAccountName($account)
    {
        if (empty($account)) {
            return '';
        }
        $lang = app()->getLocale();
        if ($lang === 'ur' && !empty($account->account_name_urdu)) {
            return htmlspecialchars($account->account_name_urdu);
        }
        return htmlspecialchars($account->account_name);
    }
}

if (!function_exists('displayItemName')) {
    function displayItemName($item)
    {
        if (empty($item)) {
            return '';
        }
        $lang = app()->getLocale();
        if ($lang === 'ur' && !empty($item->item_name_urdu)) {
            return htmlspecialchars($item->item_name_urdu);
        }
        return htmlspecialchars($item->item_name);
    }
}

if (!function_exists('generateCode')) {
    function generateCode($prefix, $lastId)
    {
        $number = str_pad($lastId + 1, 6, '0', STR_PAD_LEFT);
        return $prefix . $number;
    }
}


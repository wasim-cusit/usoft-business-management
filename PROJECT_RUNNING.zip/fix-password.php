<?php
/**
 * Password Fix Script
 * یہ فائل پاس ورڈ کو درست کرنے کے لیے ہے
 */

require_once 'config/database.php';

$username = 'adil';
$password = 'sana25';

try {
    $db = getDB();
    
    // Generate new password hash
    $newHash = password_hash($password, PASSWORD_DEFAULT);
    
    // Update password
    $stmt = $db->prepare("UPDATE users SET password = ? WHERE username = ?");
    $stmt->execute([$newHash, $username]);
    
    // Verify
    $stmt = $db->prepare("SELECT password FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        echo "<!DOCTYPE html>";
        echo "<html lang='ur' dir='rtl'>";
        echo "<head><meta charset='utf-8'><title>پاس ورڈ درست</title></head>";
        echo "<body style='font-family: Arial; padding: 20px; direction: rtl;'>";
        echo "<h1 style='color: green;'>✅ پاس ورڈ کامیابی سے درست ہو گیا!</h1>";
        echo "<p>یوزرنیم: <strong>$username</strong></p>";
        echo "<p>پاس ورڈ: <strong>$password</strong></p>";
        echo "<p><a href='login.php'>لاگ ان صفحہ پر جائیں</a></p>";
        echo "</body></html>";
    } else {
        echo "❌ پاس ورڈ درست کرنے میں خرابی";
    }
    
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage();
}
?>


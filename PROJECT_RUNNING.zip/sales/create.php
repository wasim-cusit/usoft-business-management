<?php
require_once '../config/config.php';
requireLogin();

$pageTitle = 'add_sale';
$success = '';
$error = '';

// Get accounts and items
try {
    $db = getDB();
    
    // Check if cash sale account exists, if not create it
    $stmt = $db->query("SELECT id FROM accounts WHERE account_name = 'Cash Sale' OR account_name_urdu = 'کیش فروخت' LIMIT 1");
    $cashAccount = $stmt->fetch();
    if (!$cashAccount) {
        // Create cash sale account
        try {
            $stmt = $db->prepare("INSERT INTO accounts (account_name, account_name_urdu, account_type, status) VALUES (?, ?, 'customer', 'active')");
            $stmt->execute(['Cash Sale', 'کیش فروخت']);
            $cashAccountId = $db->lastInsertId();
        } catch (PDOException $e) {
            // If creation fails, try to get existing one
            $stmt = $db->query("SELECT id FROM accounts WHERE account_name LIKE '%Cash%' OR account_name_urdu LIKE '%کیش%' LIMIT 1");
            $cashAccount = $stmt->fetch();
            $cashAccountId = $cashAccount ? $cashAccount['id'] : 0;
        }
    } else {
        $cashAccountId = $cashAccount['id'];
    }
    
    $stmt = $db->query("SELECT * FROM accounts WHERE account_type IN ('customer', 'both') AND status = 'active' ORDER BY account_name");
    $customers = $stmt->fetchAll();
    
    $stmt = $db->query("SELECT * FROM items WHERE status = 'active' ORDER BY item_name");
    $items = $stmt->fetchAll();
    
    // Get next sale number for display
    $stmt = $db->query("SELECT MAX(id) as max_id FROM sales");
    $maxId = $stmt->fetch()['max_id'] ?? 0;
    $nextNumber = $maxId + 1;
    $nextSaleNo = 'Sal' . str_pad($nextNumber, 2, '0', STR_PAD_LEFT);
} catch (PDOException $e) {
    $customers = [];
    $items = [];
    $nextSaleNo = 'Sal01';
    $cashAccountId = 0;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $saleDate = $_POST['sale_date'] ?? date('Y-m-d');
    $accountId = intval($_POST['account_id'] ?? 0);
    $discount = floatval($_POST['discount'] ?? 0);
    $paidAmount = floatval($_POST['paid_amount'] ?? 0);
    $remarks = sanitizeInput($_POST['remarks'] ?? '');
    $itemIds = $_POST['item_id'] ?? [];
    $quantities = $_POST['quantity'] ?? [];
    $rates = $_POST['rate'] ?? [];
    
    // Check if cash sale
    $isCashSale = false;
    if (isset($cashAccountId) && $accountId == $cashAccountId) {
        $isCashSale = true;
    }
    
    if (empty($accountId)) {
        $error = t('please_select_customer');
    } elseif (empty($itemIds) || !is_array($itemIds)) {
        $error = t('please_add_item');
    } else {
        try {
            $db->beginTransaction();
            
            // Calculate totals and check stock
            $totalAmount = 0;
            $validItems = [];
            for ($i = 0; $i < count($itemIds); $i++) {
                if (!empty($itemIds[$i]) && !empty($quantities[$i]) && !empty($rates[$i])) {
                    $itemId = intval($itemIds[$i]);
                    $qty = floatval($quantities[$i]);
                    $rate = floatval($rates[$i]);
                    
                    // Check stock
                    $stmt = $db->prepare("SELECT current_stock, item_name FROM items WHERE id = ?");
                    $stmt->execute([$itemId]);
                    $item = $stmt->fetch();
                    
                    if (!$item) {
                        throw new Exception(t('item_not_found'));
                    }
                    
                    // Check stock - allow sale but track warnings
                    $currentStock = floatval($item['current_stock']);
                    $stockShortage = 0;
                    if ($currentStock < $qty) {
                        $stockShortage = $qty - $currentStock;
                    }
                    
                    $amount = $qty * $rate;
                    $totalAmount += $amount;
                    $validItems[] = [
                        'item_id' => $itemId,
                        'quantity' => $qty,
                        'rate' => $rate,
                        'amount' => $amount,
                        'current_stock' => $currentStock,
                        'stock_shortage' => $stockShortage,
                        'item_name' => $item['item_name']
                    ];
                }
            }
            
            if (empty($validItems)) {
                throw new Exception(t('please_enter_item_details'));
            }
            
            $netAmount = $totalAmount - $discount;
            $balanceAmount = $netAmount - $paidAmount;
            
            // Generate sale number (Sal01, Sal02, etc.) or use provided one
            $saleNo = trim($_POST['sale_no'] ?? '');
            if (empty($saleNo)) {
                $stmt = $db->query("SELECT MAX(id) as max_id FROM sales");
                $maxId = $stmt->fetch()['max_id'] ?? 0;
                $nextNumber = $maxId + 1;
                $saleNo = 'Sal' . str_pad($nextNumber, 2, '0', STR_PAD_LEFT);
            } else {
                // Check if sale_no already exists
                $stmt = $db->prepare("SELECT id FROM sales WHERE sale_no = ?");
                $stmt->execute([$saleNo]);
                if ($stmt->fetch()) {
                    throw new Exception(t('sale_no_already_exists'));
                }
            }
            
            // Handle cash on sale or cash sale (walking customer)
            $cashOnSale = isset($_POST['cash_on_sale']) && $_POST['cash_on_sale'] == 'on';
            if ($cashOnSale || $isCashSale) {
                $paidAmount = $netAmount; // Set paid amount equal to net amount for cash sales
            }
            
            // Insert sale
            $stmt = $db->prepare("INSERT INTO sales (sale_no, sale_date, account_id, total_amount, discount, net_amount, paid_amount, balance_amount, remarks, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$saleNo, $saleDate, $accountId, $totalAmount, $discount, $netAmount, $paidAmount, $balanceAmount, $remarks, $_SESSION['user_id']]);
            
            $saleId = $db->lastInsertId();
            
            // Collect stock warnings
            $stockWarnings = [];
            
            // Insert sale items and update stock
            foreach ($validItems as $item) {
                $stmt = $db->prepare("INSERT INTO sale_items (sale_id, item_id, quantity, rate, amount) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$saleId, $item['item_id'], $item['quantity'], $item['rate'], $item['amount']]);
                
                // Check for stock shortage before updating
                if ($item['stock_shortage'] > 0) {
                    $stockWarnings[] = [
                        'item_name' => $item['item_name'],
                        'available_stock' => $item['current_stock'],
                        'required_quantity' => $item['quantity'],
                        'shortage' => $item['stock_shortage']
                    ];
                }
                
                // Update item stock (reduce for sale) - prevent negative stock (minimum 0)
                $stmt = $db->prepare("UPDATE items SET current_stock = GREATEST(0, current_stock - ?) WHERE id = ?");
                $stmt->execute([$item['quantity'], $item['item_id']]);
                
                // Add to stock movements
                $stmt = $db->prepare("SELECT current_stock FROM items WHERE id = ?");
                $stmt->execute([$item['item_id']]);
                $currentStock = $stmt->fetch()['current_stock'];
                
                $stmt = $db->prepare("INSERT INTO stock_movements (item_id, movement_date, movement_type, reference_type, reference_id, quantity_out, balance_quantity) VALUES (?, ?, 'sale', 'sale', ?, ?, ?)");
                $stmt->execute([$item['item_id'], $saleDate, $saleId, $item['quantity'], $currentStock]);
            }
            
            // Add transaction if paid
            if ($paidAmount > 0) {
                $stmt = $db->prepare("INSERT INTO transactions (transaction_date, transaction_type, account_id, amount, narration, reference_type, reference_id, created_by) VALUES (?, 'credit', ?, ?, ?, 'sale', ?, ?)");
                $stmt->execute([$saleDate, $accountId, $paidAmount, "Sale: $saleNo", $saleId, $_SESSION['user_id']]);
            }
            
            $db->commit();
            
            // Build success message with warnings if any
            $success = t('sale_added_success');
            if (!empty($stockWarnings)) {
                $warningMsg = '<br><strong>' . t('stock_warning') . ':</strong><br>';
                foreach ($stockWarnings as $warning) {
                    $warningMsg .= $warning['item_name'] . ': ' . t('available_stock') . ' = ' . $warning['available_stock'] . ', ' . t('required_quantity') . ' = ' . $warning['required_quantity'] . ', ' . t('stock_shortage') . ' = ' . $warning['shortage'] . '<br>';
                }
                $warningMsg .= '<small>' . t('low_stock_warning') . '</small>';
                $success .= $warningMsg;
            }
            
            $_POST = [];
        } catch (Exception $e) {
            $db->rollBack();
            $error = $e->getMessage();
        }
    }
}

include '../includes/header.php';
?>

<style>
.form-label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
    white-space: nowrap;
}
.form-label .text-danger {
    margin-left: 2px;
}
[dir="rtl"] .form-label .text-danger {
    margin-left: 0;
    margin-right: 2px;
}
/* Stock warning notification styling - clear background and text */
#stockWarningMessage {
    background-color: #f8d7da !important;
    border: 1px solid #f5c2c7 !important;
    color: #842029 !important;
    box-shadow: 0 4px 6px rgba(0,0,0,0.15) !important;
    opacity: 1 !important;
}
#stockWarningMessage strong,
#stockWarningMessage span,
#stockWarningMessage small {
    color: #842029 !important;
    font-weight: 600;
}
#stockWarningMessage .btn-close {
    filter: brightness(0.5);
    opacity: 1;
}
/* Add row button container styling */
.add-row-btn-container {
    display: flex;
    gap: 5px;
    align-items: center;
}
[dir="rtl"] .add-row-btn-container {
    flex-direction: row-reverse;
}
/* Hide add button in rows after first row */
#itemsBody tr:not(:first-child) .add-row-btn-container .add-row-btn {
    display: none !important;
}
</style>

<div class="page-header">
    <h1><i class="fas fa-cash-register"></i> <?php echo t('add_sale'); ?></h1>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><?php echo t('sale_info'); ?></h5>
            </div>
            <div class="card-body">
                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="" id="saleForm">
                    <div class="row mb-4 align-items-end">
                        <div class="col-md-3">
                            <label class="form-label"><?php echo t('date'); ?> <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" name="sale_date" value="<?php echo $_POST['sale_date'] ?? date('Y-m-d'); ?>" required>
                        </div>
                        
                        <div class="col-md-3">
                            <label class="form-label"><?php echo t('bill_no'); ?></label>
                            <input type="text" class="form-control" name="sale_no" id="sale_no" value="<?php echo $_POST['sale_no'] ?? ''; ?>" placeholder="<?php echo $nextSaleNo ?? 'Sal01'; ?>">
                            <?php /* <small class="text-muted d-block mt-1"><?php echo t('leave_empty_for_auto'); ?></small> */ ?>
                        </div>
                        
                        <div class="col-md-6">
                            <label class="form-label"><?php echo t('customer'); ?> <span class="text-danger">*</span></label>
                            <select class="form-select" name="account_id" id="account_id" required>
                                <option value="">-- <?php echo t('select'); ?> --</option>
                                <option value="<?php echo $cashAccountId ?? 0; ?>" style="font-weight: bold; color: #0d6efd;">
                                    <?php echo t('cash_sale'); ?>
                                </option>
                                <?php 
                                $selectedAccountId = $_POST['account_id'] ?? $_GET['account_id'] ?? '';
                                foreach ($customers as $customer): 
                                    // Skip cash account if it's already in the list
                                    if (isset($cashAccountId) && $customer['id'] == $cashAccountId) continue;
                                ?>
                                    <option value="<?php echo $customer['id']; ?>" <?php echo ($selectedAccountId == $customer['id']) ? 'selected' : ''; ?>>
                                        <?php echo displayAccountNameFull($customer); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <?php /*
                        <div class="col-md-2 d-flex align-items-center justify-content-center">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="cash_on_sale" name="cash_on_sale">
                                <label class="form-check-label" for="cash_on_sale">
                                    <?php echo t('cash_on_sale'); ?>
                                </label>
                            </div>
                        </div>
                        */ ?>
                    </div>
                    
                    <div class="row mb-4">
                        <div class="col-md-12">
                            <label class="form-label"><?php echo t('remarks'); ?></label>
                            <input type="text" class="form-control" name="remarks" value="<?php echo $_POST['remarks'] ?? ''; ?>">
                        </div>
                    </div>
                    
                    <div class="card mb-4">
                        <div class="card-header bg-light">
                            <h6 class="mb-0"><?php echo t('item_details'); ?></h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table" id="itemsTable">
                                    <thead>
                                        <tr>
                                            <th style="width: 35%;"><?php echo t('items'); ?></th>
                                            <th style="width: 15%;"><?php echo t('quantity'); ?></th>
                                            <th style="width: 15%;"><?php echo t('rate'); ?></th>
                                            <th style="width: 15%;"><?php echo t('amount'); ?></th>
                                            <th style="width: 20%;"><?php echo t('actions'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody id="itemsBody">
                                        <tr>
                                            <td>
                                                <select class="form-select item-select" name="item_id[]" required>
                                                    <option value="">-- <?php echo t('select'); ?> --</option>
                                                    <?php foreach ($items as $item): ?>
                                                        <option value="<?php echo $item['id']; ?>" data-rate="<?php echo $item['sale_rate']; ?>" data-stock="<?php echo $item['current_stock']; ?>">
                                                            <?php echo displayItemNameFull($item); ?> (<?php echo t('stock_label'); ?>: <?php echo $item['current_stock']; ?>)
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </td>
                                            <td><input type="number" step="0.01" class="form-control quantity" name="quantity[]" required></td>
                                            <td><input type="number" step="0.01" class="form-control rate" name="rate[]" required></td>
                                            <td><input type="text" class="form-control amount" readonly></td>
                                            <td>
                                                <div class="add-row-btn-container">
                                                    <button type="button" class="btn btn-success btn-sm" id="addRow" title="<?php echo t('add_item'); ?>">
                                                        <i class="fas fa-plus"></i>
                                                    </button>
                                                    <button type="button" class="btn btn-danger btn-sm remove-row" disabled><i class="fas fa-times"></i></button>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td colspan="3" class="text-end"><strong><?php echo t('total'); ?>:</strong></td>
                                            <td><input type="text" class="form-control" id="total_amount" readonly value="0.00"></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="text-end"><strong><?php echo t('discount'); ?>:</strong></td>
                                            <td><input type="number" step="0.01" class="form-control" name="discount" id="discount" placeholder="0"></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="text-end"><strong><?php echo t('net_amount'); ?>:</strong></td>
                                            <td><input type="text" class="form-control" id="net_amount" readonly value="0.00"></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="text-end"><strong><?php echo t('receipt'); ?>:</strong></td>
                                            <td><input type="number" step="0.01" class="form-control" name="paid_amount" id="paid_amount" placeholder="0"></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="text-end"><strong><?php echo t('balance_amount'); ?>:</strong></td>
                                            <td><input type="text" class="form-control" id="balance_amount" readonly value="0.00"></td>
                                            <td></td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-4">
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="fas fa-save"></i> <?php echo t('save'); ?>
                        </button>
                        <a href="<?php echo BASE_URL; ?>sales/list.php" class="btn btn-secondary btn-lg">
                            <i class="fas fa-list"></i> <?php echo t('view_list'); ?>
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script>
$(document).ready(function() {
    // Add new row
    $('#addRow').click(function() {
        var newRow = `
            <tr>
                <td>
                    <select class="form-select item-select" name="item_id[]" required>
                        <option value="">-- <?php echo t('select'); ?> --</option>
                        <?php foreach ($items as $item): ?>
                            <option value="<?php echo $item['id']; ?>" data-rate="<?php echo $item['sale_rate']; ?>" data-stock="<?php echo $item['current_stock']; ?>">
                                <?php echo htmlspecialchars($item['item_name']); ?> (<?php echo t('stock_label'); ?>: <?php echo $item['current_stock']; ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </td>
                <td><input type="number" step="0.01" class="form-control quantity" name="quantity[]" required></td>
                <td><input type="number" step="0.01" class="form-control rate" name="rate[]" required></td>
                <td><input type="text" class="form-control amount" readonly></td>
                <td>
                    <div class="add-row-btn-container">
                        <button type="button" class="btn btn-success btn-sm add-row-btn" title="<?php echo t('add_item'); ?>">
                            <i class="fas fa-plus"></i>
                        </button>
                        <button type="button" class="btn btn-danger btn-sm remove-row"><i class="fas fa-times"></i></button>
                    </div>
                </td>
            </tr>
        `;
        $('#itemsBody').append(newRow);
        // Hide add button in all rows except first
        updateAddButtons();
    });
    
    // Update add button visibility
    function updateAddButtons() {
        $('#itemsBody tr').each(function(index) {
            if (index === 0) {
                $(this).find('.add-row-btn').show();
            } else {
                $(this).find('.add-row-btn').hide();
            }
        });
    }
    
    // Remove row
    $(document).on('click', '.remove-row', function() {
        if ($('#itemsBody tr').length > 1) {
            $(this).closest('tr').remove();
            calculateTotal();
            updateAddButtons();
        } else {
            alert('<?php echo t('please_add_item'); ?>');
        }
    });
    
    // Handle add button clicks (both #addRow and .add-row-btn)
    $(document).on('click', '.add-row-btn', function() {
        $('#addRow').trigger('click');
    });
    
    // Check stock when quantity changes - show warning but allow
    $(document).on('input', '.quantity', function() {
        var row = $(this).closest('tr');
        var qty = parseFloat($(this).val()) || 0;
        var stock = parseFloat(row.find('.item-select option:selected').data('stock')) || 0;
        var itemSelect = row.find('.item-select');
        var itemName = itemSelect.find('option:selected').text().split(' (')[0] || '';
        
        // Show warning if stock is low but don't block
        if (qty > stock && qty > 0 && itemName) {
            var shortage = qty - stock;
            
            // Show warning message
            if ($('#stockWarningMessage').length === 0) {
                $('body').prepend('<div id="stockWarningMessage" class="alert alert-danger alert-dismissible fade show" style="position: fixed; top: 20px; right: 20px; z-index: 9999; max-width: 400px; background-color: #f8d7da !important; border-color: #f5c2c7 !important; color: #842029 !important; box-shadow: 0 4px 6px rgba(0,0,0,0.1);"><button type="button" class="btn-close" data-bs-dismiss="alert" style="filter: brightness(0.5);"></button><strong style="color: #842029 !important;"><?php echo t('stock_warning'); ?>:</strong> <span style="color: #842029 !important;">' + itemName + ' - <?php echo t('available_stock'); ?>: ' + stock + ', <?php echo t('required_quantity'); ?>: ' + qty + ', <?php echo t('stock_shortage'); ?>: ' + shortage + '</span><br><small style="color: #842029 !important;"><?php echo t('low_stock_warning'); ?></small></div>');
            } else {
                $('#stockWarningMessage').removeClass('alert-warning').addClass('alert-danger').css({
                    'background-color': '#f8d7da',
                    'border-color': '#f5c2c7',
                    'color': '#842029',
                    'box-shadow': '0 4px 6px rgba(0,0,0,0.1)'
                }).html('<button type="button" class="btn-close" data-bs-dismiss="alert" style="filter: brightness(0.5);"></button><strong style="color: #842029 !important;"><?php echo t('stock_warning'); ?>:</strong> <span style="color: #842029 !important;">' + itemName + ' - <?php echo t('available_stock'); ?>: ' + stock + ', <?php echo t('required_quantity'); ?>: ' + qty + ', <?php echo t('stock_shortage'); ?>: ' + shortage + '</span><br><small style="color: #842029 !important;"><?php echo t('low_stock_warning'); ?></small>').show();
            }
            
            // Auto-hide after 5 seconds
            setTimeout(function() {
                $('#stockWarningMessage').fadeOut();
            }, 5000);
        } else {
            // Clear warning if stock is sufficient
            $('#stockWarningMessage').fadeOut();
        }
        
        calculateRowAmount(row);
    });
    
    // Calculate amount
    function calculateRowAmount(row) {
        var qty = parseFloat(row.find('.quantity').val()) || 0;
        var rate = parseFloat(row.find('.rate').val()) || 0;
        var amount = qty * rate;
        row.find('.amount').val(formatNumber(amount));
        calculateTotal();
    }
    
    $(document).on('input', '.rate', function() {
        calculateRowAmount($(this).closest('tr'));
    });
    
    // Set rate when item selected
    $(document).on('change', '.item-select', function() {
        var row = $(this).closest('tr');
        var rate = $(this).find('option:selected').data('rate');
        
        if (rate) {
            row.find('.rate').val(rate);
        }
        
        // Remove max attribute to allow any quantity
        row.find('.quantity').removeAttr('max');
        
        calculateRowAmount(row);
    });
    
    // Calculate totals
    function calculateTotal() {
        var total = 0;
        $('.amount').each(function() {
            total += parseFloat(String($(this).val()).replace(/,/g, '')) || 0;
        });
        $('#total_amount').val(formatNumber(total));
        
        var discount = parseFloat(String($('#discount').val()).replace(/,/g, '')) || 0;
        var netAmount = total - discount;
        $('#net_amount').val(formatNumber(netAmount));
        
        var paid = parseFloat(String($('#paid_amount').val()).replace(/,/g, '')) || 0;
        var balance = netAmount - paid;
        $('#balance_amount').val(formatNumber(balance));
    }
    
    $('#discount, #paid_amount').on('input', calculateTotal);
    
    // Handle customer selection - auto-check cash on sale for cash sale account
    $('#account_id').on('change', function() {
        var selectedValue = $(this).val();
        var cashAccountId = <?php echo $cashAccountId ?? 0; ?>;
        
        if (selectedValue == cashAccountId && cashAccountId > 0) {
            // Auto-check cash on sale for cash sale account
            $('#cash_on_sale').prop('checked', true);
            // Auto-fill paid amount
            setTimeout(function() {
                var netAmount = parseFloat($('#net_amount').val()) || 0;
                $('#paid_amount').val(formatNumber(netAmount));
                calculateTotal();
            }, 100);
        } else {
            // Uncheck if not cash sale
            if ($('#cash_on_sale').is(':checked') && $('#paid_amount').val() == $('#net_amount').val()) {
                // Only uncheck if paid amount matches net amount (was auto-filled)
                $('#cash_on_sale').prop('checked', false);
            }
        }
    });
    
    // Handle cash on sale checkbox
    $('#cash_on_sale').on('change', function() {
        if ($(this).is(':checked')) {
            // Set paid amount equal to net amount
            var netAmount = parseFloat($('#net_amount').val()) || 0;
            $('#paid_amount').val(formatNumber(netAmount));
            calculateTotal();
        } else {
            // Clear paid amount if unchecked
            $('#paid_amount').val('');
            calculateTotal();
        }
    });
    
    // Update paid amount when net amount changes (if cash on sale is checked)
    $('#discount').on('input', function() {
        if ($('#cash_on_sale').is(':checked')) {
            setTimeout(function() {
                var netAmount = parseFloat($('#net_amount').val()) || 0;
                $('#paid_amount').val(formatNumber(netAmount));
                calculateTotal();
            }, 100);
        }
    });
});
</script>

<?php include '../includes/footer.php'; ?>


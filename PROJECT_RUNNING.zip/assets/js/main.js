// Main JavaScript File
// Business Management System

$(document).ready(function() {
    // Auto-hide alerts after 5 seconds (except those with no-auto-hide class)
    setTimeout(function() {
        $('.alert:not(.no-auto-hide)').fadeOut('slow');
    }, 5000);
    
    // Confirm delete actions
    $('.btn-delete').on('click', function(e) {
        if (!confirm('کیا آپ واقعی یہ ریکارڈ حذف کرنا چاہتے ہیں؟')) {
            e.preventDefault();
        }
    });
    
    // Format currency inputs - use global formatNumber function
    $('.currency-input').on('blur', function() {
        var value = parseFloat($(this).val()) || 0;
        if (typeof formatNumber === 'function') {
            $(this).val(formatNumber(value));
        } else {
            // Fallback if formatNumber not available
            if (value % 1 === 0) {
                $(this).val(value.toLocaleString('en-US', {minimumFractionDigits: 0, maximumFractionDigits: 0}));
            } else {
                $(this).val(value.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}));
            }
        }
    });
    
    // Calculate totals in forms
    $('.calculate-total').on('input', function() {
        calculateTotal();
    });
    
    function calculateTotal() {
        var total = 0;
        $('.item-amount').each(function() {
            total += parseFloat(String($(this).val()).replace(/,/g, '')) || 0;
        });
        if (typeof formatNumber === 'function') {
            $('#total_amount').val(formatNumber(total));
        } else {
            $('#total_amount').val(total % 1 === 0 ? total.toLocaleString('en-US', {minimumFractionDigits: 0, maximumFractionDigits: 0}) : total.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}));
        }
        
        var discount = parseFloat(String($('#discount').val()).replace(/,/g, '')) || 0;
        var netAmount = total - discount;
        if (typeof formatNumber === 'function') {
            $('#net_amount').val(formatNumber(netAmount));
        } else {
            $('#net_amount').val(netAmount % 1 === 0 ? netAmount.toLocaleString('en-US', {minimumFractionDigits: 0, maximumFractionDigits: 0}) : netAmount.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}));
        }
    }
});

// Print function
function printPage() {
    window.print();
}

// Export to PDF (placeholder)
function exportToPDF() {
    alert('PDF ایکسپورٹ فیچر جلد شامل کیا جائے گا');
}


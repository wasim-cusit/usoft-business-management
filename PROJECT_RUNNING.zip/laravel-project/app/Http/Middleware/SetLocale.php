<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;

class SetLocale
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        // Get language from request, session, or default to Urdu
        $locale = $request->get('lang') 
            ?? Session::get('language') 
            ?? config('app.locale', 'ur');
        
        // Validate locale
        if (!in_array($locale, ['en', 'ur'])) {
            $locale = 'ur';
        }
        
        // Set locale
        App::setLocale($locale);
        Session::put('language', $locale);
        
        return $next($request);
    }
}


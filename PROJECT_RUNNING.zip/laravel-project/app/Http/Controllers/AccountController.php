<?php

namespace App\Http\Controllers;

use App\Models\Account;
use App\Models\UserType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AccountController extends Controller
{
    /**
     * Display a listing of accounts
     */
    public function index(Request $request)
    {
        $query = Account::with('userType');
        
        // Search functionality
        if ($request->has('search') && $request->search) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('account_name', 'like', "%{$search}%")
                  ->orWhere('account_name_urdu', 'like', "%{$search}%")
                  ->orWhere('account_code', 'like', "%{$search}%")
                  ->orWhere('phone', 'like', "%{$search}%")
                  ->orWhere('mobile', 'like', "%{$search}%");
            });
        }
        
        // Filter by account type
        if ($request->has('account_type') && $request->account_type) {
            $query->where('account_type', $request->account_type);
        }
        
        // Filter by status
        if ($request->has('status') && $request->status !== '') {
            $query->where('status', $request->status);
        } else {
            $query->where('status', 'active');
        }
        
        $accounts = $query->orderBy('id', 'desc')->paginate(20);
        
        return view('accounts.index', compact('accounts'));
    }
    
    /**
     * Show the form for creating a new account
     */
    public function create()
    {
        $userTypes = UserType::orderBy('type_name')->get();
        return view('accounts.create', compact('userTypes'));
    }
    
    /**
     * Store a newly created account
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'account_name' => 'required|string|max:100',
            'account_name_urdu' => 'nullable|string|max:100',
            'account_type' => 'required|in:customer,supplier,both',
            'user_type_id' => 'nullable|exists:user_types,id',
            'contact_person' => 'nullable|string|max:100',
            'phone' => 'nullable|string|max:20',
            'mobile' => 'nullable|string|max:20',
            'email' => 'nullable|email|max:100',
            'address' => 'nullable|string',
            'city' => 'nullable|string|max:50',
            'opening_balance' => 'nullable|numeric|min:0',
            'balance_type' => 'required|in:debit,credit',
            'status' => 'required|in:active,inactive',
        ]);
        
        // Generate account code if not provided
        if (empty($validated['account_code'])) {
            $lastAccount = Account::orderBy('id', 'desc')->first();
            $lastId = $lastAccount ? $lastAccount->id : 0;
            $validated['account_code'] = generateCode('ACC', $lastId);
        }
        
        Account::create($validated);
        
        return redirect()->route('accounts.index')
            ->with('success', __('account_added_success'));
    }
    
    /**
     * Display the specified account
     */
    public function show(Account $account)
    {
        $account->load(['userType', 'purchases', 'sales', 'transactions']);
        
        // Calculate balance
        $balance = $this->calculateBalance($account);
        
        return view('accounts.show', compact('account', 'balance'));
    }
    
    /**
     * Show the form for editing the specified account
     */
    public function edit(Account $account)
    {
        $userTypes = UserType::orderBy('type_name')->get();
        return view('accounts.edit', compact('account', 'userTypes'));
    }
    
    /**
     * Update the specified account
     */
    public function update(Request $request, Account $account)
    {
        $validated = $request->validate([
            'account_name' => 'required|string|max:100',
            'account_name_urdu' => 'nullable|string|max:100',
            'account_type' => 'required|in:customer,supplier,both',
            'user_type_id' => 'nullable|exists:user_types,id',
            'contact_person' => 'nullable|string|max:100',
            'phone' => 'nullable|string|max:20',
            'mobile' => 'nullable|string|max:20',
            'email' => 'nullable|email|max:100',
            'address' => 'nullable|string',
            'city' => 'nullable|string|max:50',
            'opening_balance' => 'nullable|numeric|min:0',
            'balance_type' => 'required|in:debit,credit',
            'status' => 'required|in:active,inactive',
        ]);
        
        $account->update($validated);
        
        return redirect()->route('accounts.index')
            ->with('success', __('account_updated_success'));
    }
    
    /**
     * Remove the specified account
     */
    public function destroy(Account $account)
    {
        // Check if account has transactions
        if ($account->purchases()->count() > 0 || $account->sales()->count() > 0) {
            return redirect()->route('accounts.index')
                ->with('error', __('cannot_delete_account_in_use'));
        }
        
        $account->delete();
        
        return redirect()->route('accounts.index')
            ->with('success', __('account_deleted_success'));
    }
    
    /**
     * Calculate account balance
     */
    private function calculateBalance(Account $account)
    {
        $openingBalance = $account->opening_balance;
        $openingType = $account->balance_type;
        
        // Calculate from purchases
        $purchaseDebit = $account->purchases()->sum('balance_amount');
        
        // Calculate from sales
        $saleCredit = $account->sales()->sum('balance_amount');
        
        // Calculate from transactions
        $transactionDebit = $account->transactions()
            ->where('transaction_type', 'debit')
            ->sum('amount');
        $transactionCredit = $account->transactions()
            ->where('transaction_type', 'credit')
            ->sum('amount');
        
        // Net balance
        $balance = $openingBalance;
        if ($openingType === 'debit') {
            $balance += $purchaseDebit + $transactionDebit - $saleCredit - $transactionCredit;
        } else {
            $balance = $saleCredit + $transactionCredit - $purchaseDebit - $transactionDebit - $balance;
        }
        
        return $balance;
    }
}


<?php

namespace App\Http\Controllers;

use App\Models\UserType;
use Illuminate\Http\Request;

class UserTypeController extends Controller
{
    /**
     * Display a listing of user types
     */
    public function index()
    {
        $userTypes = UserType::orderBy('id', 'desc')->get();
        return view('user-types.index', compact('userTypes'));
    }
    
    /**
     * Store a newly created user type
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'type_name' => 'required|string|max:50|unique:user_types,type_name',
            'type_name_urdu' => 'nullable|string|max:100',
            'description' => 'nullable|string',
        ]);
        
        UserType::create($validated);
        
        return redirect()->route('user-types.index')
            ->with('success', __('user_type_added_success'));
    }
    
    /**
     * Update the specified user type
     */
    public function update(Request $request, UserType $userType)
    {
        $validated = $request->validate([
            'type_name' => 'required|string|max:50|unique:user_types,type_name,' . $userType->id,
            'type_name_urdu' => 'nullable|string|max:100',
            'description' => 'nullable|string',
        ]);
        
        $userType->update($validated);
        
        return redirect()->route('user-types.index')
            ->with('success', __('user_type_updated_success'));
    }
    
    /**
     * Remove the specified user type
     */
    public function destroy(UserType $userType)
    {
        // Check if user type is being used
        if ($userType->accounts()->count() > 0) {
            return redirect()->route('user-types.index')
                ->with('error', __('cannot_delete_user_type_in_use'));
        }
        
        $userType->delete();
        
        return redirect()->route('user-types.index')
            ->with('success', __('user_type_deleted_success'));
    }
}


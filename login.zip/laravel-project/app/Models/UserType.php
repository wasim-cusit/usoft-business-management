<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserType extends Model
{
    protected $fillable = [
        'type_name',
        'type_name_urdu',
        'description',
    ];

    public function accounts()
    {
        return $this->hasMany(Account::class);
    }
}


<?php

namespace Database\Seeders;

use App\Models\UserType;
use Illuminate\Database\Seeder;

class UserTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        UserType::create([
            'type_name' => 'Customer',
            'type_name_urdu' => 'کسٹمر',
            'description' => 'Regular customer type',
        ]);
        
        UserType::create([
            'type_name' => 'Supplier',
            'type_name_urdu' => 'سپلائر',
            'description' => 'Supplier type',
        ]);
        
        UserType::create([
            'type_name' => 'Both',
            'type_name_urdu' => 'دونوں',
            'description' => 'Both customer and supplier',
        ]);
    }
}


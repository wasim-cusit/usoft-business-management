<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\AccountController;
use App\Http\Controllers\ItemController;
use App\Http\Controllers\PurchaseController;
use App\Http\Controllers\SaleController;
use App\Http\Controllers\TransactionController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\UserTypeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// Authentication Routes
Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login')->middleware('guest');
Route::post('/login', [LoginController::class, 'login']);
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

// All routes below require authentication
Route::middleware(['auth'])->group(function () {
    
    // Dashboard
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    
    // Accounts Routes
    Route::prefix('accounts')->name('accounts.')->group(function () {
        Route::get('/', [AccountController::class, 'index'])->name('index');
        Route::get('/create', [AccountController::class, 'create'])->name('create');
        Route::post('/', [AccountController::class, 'store'])->name('store');
        Route::get('/{account}', [AccountController::class, 'show'])->name('show');
        Route::get('/{account}/edit', [AccountController::class, 'edit'])->name('edit');
        Route::put('/{account}', [AccountController::class, 'update'])->name('update');
        Route::delete('/{account}', [AccountController::class, 'destroy'])->name('destroy');
    });
    
    // User Types Routes
    Route::resource('user-types', UserTypeController::class);
    
    // Items Routes
    Route::resource('items', ItemController::class);
    
    // Purchases Routes
    Route::prefix('purchases')->name('purchases.')->group(function () {
        Route::get('/', [PurchaseController::class, 'index'])->name('index');
        Route::get('/create', [PurchaseController::class, 'create'])->name('create');
        Route::post('/', [PurchaseController::class, 'store'])->name('store');
        Route::get('/{purchase}', [PurchaseController::class, 'show'])->name('show');
    });
    
    // Sales Routes
    Route::prefix('sales')->name('sales.')->group(function () {
        Route::get('/', [SaleController::class, 'index'])->name('index');
        Route::get('/create', [SaleController::class, 'create'])->name('create');
        Route::post('/', [SaleController::class, 'store'])->name('store');
        Route::get('/{sale}', [SaleController::class, 'show'])->name('show');
    });
    
    // Transactions Routes
    Route::prefix('transactions')->name('transactions.')->group(function () {
        Route::get('/debit', [TransactionController::class, 'debit'])->name('debit');
        Route::post('/debit', [TransactionController::class, 'storeDebit'])->name('debit.store');
        Route::get('/credit', [TransactionController::class, 'credit'])->name('credit');
        Route::post('/credit', [TransactionController::class, 'storeCredit'])->name('credit.store');
        Route::get('/journal', [TransactionController::class, 'journal'])->name('journal');
        Route::post('/journal', [TransactionController::class, 'storeJournal'])->name('journal.store');
        Route::get('/', [TransactionController::class, 'index'])->name('index');
    });
    
    // Reports Routes
    Route::prefix('reports')->name('reports.')->group(function () {
        Route::get('/party-ledger', [ReportController::class, 'partyLedger'])->name('party-ledger');
        Route::get('/stock-detail', [ReportController::class, 'stockDetail'])->name('stock-detail');
        Route::get('/stock-ledger', [ReportController::class, 'stockLedger'])->name('stock-ledger');
        Route::get('/balance-sheet', [ReportController::class, 'balanceSheet'])->name('balance-sheet');
        Route::get('/cash-book', [ReportController::class, 'cashBook'])->name('cash-book');
        Route::get('/daily-book', [ReportController::class, 'dailyBook'])->name('daily-book');
        Route::get('/loan-slip', [ReportController::class, 'loanSlip'])->name('loan-slip');
        Route::get('/rate-list', [ReportController::class, 'rateList'])->name('rate-list');
        Route::get('/stock-check', [ReportController::class, 'stockCheck'])->name('stock-check');
        Route::get('/all-bills', [ReportController::class, 'allBills'])->name('all-bills');
    });
});

